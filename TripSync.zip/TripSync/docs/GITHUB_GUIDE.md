# Pushing TripSync to Your Own GitHub

You received this project as a ZIP file. Here's how to get it running locally and then
push it to your own GitHub account.

## 1. Unzip and open a terminal there

Extract `TripSync.zip` anywhere on your computer, then open a terminal (Command Prompt,
PowerShell, or Terminal on Mac) inside the extracted `TripSync` folder.

## 2. Run it locally first (see `docs/DEPLOYMENT.md`)

Quickest path — with Docker Desktop installed:

```bash
cp backend/.env.example backend/.env
# edit backend/.env and set JWT_SECRET to any long random string
docker compose up --build
```

Then open http://localhost:5173 and confirm the app loads, you can register, and create
a trip. Once confirmed, stop it with `docker compose down` before pushing to Git (no need
to keep it running).

## 3. Create a new repository on GitHub

1. Go to https://github.com/new
2. Name it (e.g. `tripsync`), choose Public or Private, **do not** check "Add a README"
   (this project already has one) — leave it empty.
3. Click **Create repository**. Copy the URL it shows you, e.g.
   `https://github.com/<your-username>/tripsync.git`

## 4. Initialize Git and push

From inside the `TripSync` folder:

```bash
git init
git add .
git commit -m "Initial commit: TripSync full-stack project"
git branch -M main
git remote add origin https://github.com/<your-username>/tripsync.git
git push -u origin main
```

If prompted, sign in with your GitHub credentials (GitHub now requires a Personal Access
Token instead of a password for the command line — GitHub will show you a link to create
one if needed, or use `gh auth login` if you have the GitHub CLI installed).

## 5. Double-check secrets aren't committed

The project's `.gitignore` already excludes `backend/.env` and `frontend/.env` (where real
secrets live), plus `node_modules/`, `target/`, and `uploads/`. Before pushing, you can run:

```bash
git status
```

and confirm no `.env` file is listed as "to be committed." If it accidentally shows up,
remove it from staging with `git rm --cached backend/.env` before committing.

## 6. Done

Your repository is now live at `https://github.com/<your-username>/tripsync`. Anyone
cloning it can follow the main `README.md` to run it themselves.
