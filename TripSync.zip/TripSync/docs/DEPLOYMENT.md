# TripSync — Deployment & Setup Guide

Two ways to run TripSync locally: **Docker Compose** (recommended, one command) or
**manual setup** (install Java/Node/MySQL yourself).

## Option A — Docker Compose (recommended)

### Prerequisites
- [Docker Desktop](https://www.docker.com/products/docker-desktop/) installed and running
- Git

### Steps

```bash
git clone <your-repo-url>
cd TripSync
cp backend/.env.example backend/.env
```

Open `backend/.env` and at minimum set `JWT_SECRET` to a long random string. Everything
else can be left at defaults for local use (email stays disabled/logged to console).

```bash
docker compose up --build
```

Wait for all three containers (mysql, backend, frontend) to report healthy — first run
downloads dependencies and can take 3–5 minutes. Then open:

- App: http://localhost:5173
- API: http://localhost:8080/api
- Swagger UI: http://localhost:8080/swagger-ui.html

To stop: `docker compose down` (add `-v` to also wipe the database volume).

## Option B — Manual (no Docker)

### Prerequisites
- Java 21 (JDK)
- Maven 3.9+ (or use the included wrapper if present)
- Node.js 20+ and npm
- MySQL 8 running locally

### 1. Database

```sql
CREATE DATABASE tripsync;
CREATE USER 'tripsync'@'localhost' IDENTIFIED BY 'tripsync';
GRANT ALL PRIVILEGES ON tripsync.* TO 'tripsync'@'localhost';
FLUSH PRIVILEGES;
```

### 2. Backend

```bash
cd backend
cp .env.example .env    # edit JWT_SECRET at minimum
# Export the vars in .env into your shell, or use an IDE run config / direnv
mvn spring-boot:run
```

The backend starts on http://localhost:8080. Hibernate auto-creates tables (`ddl-auto: update`)
on first run.

### 3. Frontend

```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```

Open http://localhost:5173.

## Environment Variables Reference (backend/.env)

| Variable | Purpose | Default |
|---|---|---|
| `JWT_SECRET` | Signs JWT tokens — must be long/random in production | dev placeholder |
| `JWT_EXPIRATION_MS` | Token lifetime in ms | 86400000 (24h) |
| `CORS_ALLOWED_ORIGINS` | Comma-separated allowed frontend origins | localhost:5173,3000 |
| `MAIL_ENABLED` | `true` to send real emails via SMTP | `false` |
| `SMTP_HOST` / `SMTP_PORT` / `SMTP_USERNAME` / `SMTP_PASSWORD` | SMTP credentials | empty |
| `MAIL_FROM` | From address for outgoing email | no-reply@tripsync.app |
| `FRONTEND_BASE_URL` | Used to build links inside emails | http://localhost:5173 |
| `UPLOAD_DIR` | Where uploaded photos/documents are stored | `uploads` |

## Building a Production JAR / Frontend Bundle

```bash
# Backend
cd backend && mvn clean package
java -jar target/tripsync-backend.jar

# Frontend
cd frontend && npm run build
# static files land in frontend/dist/ — serve with any static host / nginx
```

## Troubleshooting

- **Backend can't connect to MySQL**: confirm MySQL is running and `DB_HOST`/`DB_PORT`/
  `DB_USER`/`DB_PASSWORD` match your setup (Docker Compose sets these automatically).
- **CORS errors in the browser console**: make sure `CORS_ALLOWED_ORIGINS` includes the
  exact origin the frontend is served from.
- **Uploaded photos/documents don't load**: confirm the backend's `uploads/` folder is
  writable and that `VITE_API_BASE_URL` in the frontend points at the right backend host.
- **Port already in use**: change the host-side port mapping in `docker-compose.yml`
  (e.g. `"5174:80"`) or stop whatever else is using 5173/8080/3306.
