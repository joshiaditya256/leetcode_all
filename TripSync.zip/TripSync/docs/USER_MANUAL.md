# TripSync — User Manual

## Getting Started

1. Go to the app and click **Get Started** to register with your name, email, and password.
2. You'll land on your **Dashboard**, showing your trips, pending invitations, and notifications.

## Creating a Trip (Coordinator)

1. Click **Create Trip**, fill in name, destination, dates, and optional budget.
2. Optionally invite members immediately by email (they must already have a TripSync account).
3. You become the trip's **Coordinator** automatically.

## As a Coordinator, you can

- **Members tab**: invite/remove members.
- **Responsibilities tab**: assign tasks (Hotel Booking, Snacks, Camera, etc.) with a due
  date and priority; everyone sees a Kanban-style board (Pending / In Progress / Completed).
- **Itinerary tab**: build a day-by-day schedule with time, activity, place, and a responsible
  person. Members see today's plan the moment they open the trip.
- **Suggestions tab**: approve or reject member-submitted suggestions; approving can add
  the suggestion straight into the itinerary.
- **Overview tab**: mark the trip completed, archive it, or delete it.

## As a Member, you can

- Accept or decline trip invitations from your Dashboard.
- View the itinerary and today's plan.
- Update the status of tasks assigned to you.
- Submit suggestions (hotel, restaurant, spot, budget, route, activity) and vote/comment
  on others' suggestions.
- Add expenses and see who owes whom in the **Expenses** tab's settlement summary.
- Check off shared **Checklist** items (Charger, Medicines, Passport, etc.).
- Upload photos/videos to the **Album**, and documents (tickets, ID, confirmations) to
  **Documents**.
- Set your **Availability** on the Members tab so the coordinator knows when you're free.

## Expenses & Settlement

Add an expense, who paid, and who it should be split between (defaults to everyone). The
**Expenses** tab shows total spent vs. budget and a settlement summary — the minimum set
of payments needed to settle all balances in the group.

## Notifications

You'll get a notification for invitations, task assignments/completions, new suggestions,
suggestion approvals, budget updates, and itinerary changes. The bell icon in the navbar
shows your unread count.

## Admin

Platform admins (role flipped manually in the database — see the main README) get an
**Admin** link with user management (activate/deactivate accounts), a list of all trips,
and basic analytics.
