# TripSync API Overview

Full interactive documentation (request/response schemas, try-it-out) is generated
automatically at **`/swagger-ui.html`** once the backend is running. This file is a quick
map of what exists.

Base URL: `http://localhost:8080/api`

Auth: send `Authorization: Bearer <token>` on every request except `/auth/register`,
`/auth/login`, `/auth/forgot-password`, `/auth/reset-password`, `/auth/verify-email`.

## Auth
| Method | Path | Notes |
|---|---|---|
| POST | `/auth/register` | Creates account, returns JWT |
| POST | `/auth/login` | Returns JWT |
| GET | `/auth/verify-email?token=` | |
| POST | `/auth/forgot-password` | Always returns success (no email enumeration) |
| POST | `/auth/reset-password` | |
| POST | `/auth/change-password` | Requires auth |
| GET / PUT | `/auth/me` | Get/update own profile |

## Trips
`GET/POST /trips`, `GET/PUT/DELETE /trips/{id}`, `POST /trips/{id}/archive|close|leave`

## Members
`GET /trips/{id}/members`, `POST /trips/{id}/members/invite`,
`POST /trips/{id}/members/respond?accept=true|false`, `DELETE /trips/{id}/members/{userId}`,
`PUT /trips/{id}/members/availability`

## Responsibilities
`GET/POST /trips/{id}/responsibilities`, `PUT/DELETE /trips/{id}/responsibilities/{rid}`

## Itinerary
`GET/POST /trips/{id}/itinerary`, `GET /trips/{id}/itinerary/today`,
`PUT/DELETE /trips/{id}/itinerary/{iid}`

## Suggestions
`GET/POST /trips/{id}/suggestions`, `POST /trips/{id}/suggestions/{sid}/vote`,
`GET/POST /trips/{id}/suggestions/{sid}/comments`,
`POST /trips/{id}/suggestions/{sid}/approve?addToItinerary=&dayNumber=&date=`,
`POST /trips/{id}/suggestions/{sid}/reject`

## Checklist
`GET/POST /trips/{id}/checklist`, `PUT/DELETE /trips/{id}/checklist/{cid}`

## Expenses
`GET/POST /trips/{id}/expenses`, `DELETE /trips/{id}/expenses/{eid}`,
`GET /trips/{id}/expenses/summary` (totals, per-member balances, settlement transfers)

## Album
`GET /trips/{id}/album`, `POST /trips/{id}/album` (multipart file upload),
`DELETE /trips/{id}/album/{mid}`, `POST /trips/{id}/album/{mid}/like`,
`GET/POST /trips/{id}/album/{mid}/comments`

## Documents
`GET /trips/{id}/documents`, `POST /trips/{id}/documents` (multipart), `DELETE .../{did}`

## Notifications
`GET /notifications`, `GET /notifications/recent`, `GET /notifications/unread-count`,
`PATCH /notifications/{id}/read`, `PATCH /notifications/read-all`

## Dashboard
`GET /dashboard` (personal dashboard), `GET /dashboard/trips/{id}` (trip dashboard)

## Admin (requires ROLE_ADMIN)
`GET /admin/users`, `PATCH /admin/users/{id}/activate|deactivate`,
`PATCH /admin/users/{id}/role?role=ADMIN|USER`, `GET /admin/trips`, `GET /admin/analytics`
