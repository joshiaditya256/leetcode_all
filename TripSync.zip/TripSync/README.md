# TripSync – Collaborative Group Trip Planning & Coordination Platform

TripSync is a full-stack web app for planning group trips together: create a trip, invite
members, assign responsibilities, build a day-wise itinerary, track a shared budget, vote on
suggestions, pack together with a shared checklist, and keep a shared photo album and document
vault — all in one place.

## Tech Stack

- **Frontend:** React (Vite), React Router, Axios, Bootstrap 5
- **Backend:** Java 21, Spring Boot 3, Spring Security, JWT, Hibernate/JPA
- **Database:** MySQL 8
- **Build Tool:** Maven
- **API Docs:** Swagger / OpenAPI (`/swagger-ui.html`)
- **Containers:** Docker & Docker Compose

## Project Structure

```
TripSync/
├── backend/          Spring Boot REST API (Java 21)
├── frontend/          React (Vite) single-page app
├── docker-compose.yml Runs MySQL + backend + frontend together
└── docs/              Setup & deployment notes
```

## Quick Start (Docker Compose — recommended)

Prerequisites: **Docker Desktop** installed and running.

```bash
git clone <your-repo-url>
cd TripSync
cp backend/.env.example backend/.env      # fill in JWT secret + (optional) SMTP creds
docker compose up --build
```

- Frontend: http://localhost:5173
- Backend API: http://localhost:8080/api
- Swagger UI: http://localhost:8080/swagger-ui.html
- MySQL: localhost:3306 (db: `tripsync`, user: `tripsync`, password: `tripsync`)

First run takes a few minutes while Maven/npm dependencies download.

## Running Without Docker

See `docs/DEPLOYMENT.md` for manual setup (local MySQL, `mvn spring-boot:run`, `npm run dev`).

## Default Login

Register a new account from the app (`/register`). The **first** user to register a trip
automatically becomes that trip's **Coordinator**. To create a platform **Admin**, register
normally then flip the `role` column for that user to `ADMIN` in MySQL:

```sql
UPDATE users SET role = 'ADMIN' WHERE email = 'you@example.com';
```

## Email (Verification / Password Reset)

The backend is wired to send real emails via SMTP (`JavaMailSender`). Until you add SMTP
credentials to `backend/.env`, verification links and reset tokens are simply logged to the
backend console — the app is fully usable without SMTP configured.

## Documentation

- `docs/DEPLOYMENT.md` — local & Docker setup, environment variables
- `docs/API.md` — module/endpoint overview (full interactive docs at `/swagger-ui.html`)
- `docs/USER_MANUAL.md` — how to use TripSync as a coordinator/member
- `docs/GITHUB_GUIDE.md` — how to push this project to your own GitHub repo

## License

Built as an individual project per the TripSync SRS v1.0.
