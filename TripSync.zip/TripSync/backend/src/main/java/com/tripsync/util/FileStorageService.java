package com.tripsync.util;

import com.tripsync.exception.BadRequestException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

@Service
public class FileStorageService {

    @Value("${app.upload.dir}")
    private String uploadDir;

    /**
     * Stores a file under uploads/{subFolder}/ and returns a web-accessible relative path
     * such as "/uploads/album/abc123.jpg".
     */
    public String store(MultipartFile file, String subFolder) {
        if (file == null || file.isEmpty()) {
            throw new BadRequestException("Uploaded file is empty");
        }
        try {
            Path folder = Paths.get(uploadDir, subFolder).toAbsolutePath().normalize();
            Files.createDirectories(folder);

            String originalName = file.getOriginalFilename() == null ? "file" : file.getOriginalFilename();
            String extension = "";
            int dot = originalName.lastIndexOf('.');
            if (dot >= 0) {
                extension = originalName.substring(dot);
            }
            String storedName = UUID.randomUUID() + extension;
            Path target = folder.resolve(storedName);
            Files.copy(file.getInputStream(), target);

            return "/uploads/" + subFolder + "/" + storedName;
        } catch (IOException e) {
            throw new BadRequestException("Failed to store file: " + e.getMessage());
        }
    }
}
