package com.tripsync.util;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 * Sends verification / password-reset emails via SMTP when app.mail.enabled=true.
 * When disabled (default for local dev without SMTP credentials), the message is
 * simply logged to the console so the flow remains fully testable end-to-end.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class MailService {

    private final JavaMailSender mailSender;

    @Value("${app.mail.enabled:false}")
    private boolean mailEnabled;

    @Value("${app.mail.from}")
    private String from;

    @Value("${app.frontend.base-url}")
    private String frontendBaseUrl;

    @Async
    public void sendVerificationEmail(String to, String token) {
        String link = frontendBaseUrl + "/verify-email?token=" + token;
        String body = "Welcome to TripSync! Verify your email by visiting:\n" + link;
        send(to, "Verify your TripSync account", body, link);
    }

    @Async
    public void sendPasswordResetEmail(String to, String token) {
        String link = frontendBaseUrl + "/reset-password?token=" + token;
        String body = "You requested a password reset. Reset your password here:\n" + link +
                "\n\nThis link expires in 30 minutes. If you didn't request this, ignore this email.";
        send(to, "Reset your TripSync password", body, link);
    }

    private void send(String to, String subject, String body, String logLink) {
        if (!mailEnabled) {
            log.info("[MAIL DISABLED] To: {} | Subject: {} | Link: {}", to, subject, logLink);
            return;
        }
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(from);
            message.setTo(to);
            message.setSubject(subject);
            message.setText(body);
            mailSender.send(message);
        } catch (Exception e) {
            log.error("Failed to send email to {}: {}", to, e.getMessage());
        }
    }
}
