package com.tripsync.repository;

import com.tripsync.entity.AlbumMedia;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AlbumMediaRepository extends JpaRepository<AlbumMedia, Long> {
    List<AlbumMedia> findByTripIdOrderByDayNumberAscCreatedAtAsc(Long tripId);
}
