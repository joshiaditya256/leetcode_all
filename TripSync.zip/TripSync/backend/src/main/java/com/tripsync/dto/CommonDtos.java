package com.tripsync.dto;

import java.time.LocalDateTime;

public class CommonDtos {

    public record ErrorResponse(LocalDateTime timestamp, int status, String message) {}

    public record ApiResponse(boolean success, String message) {
        public static ApiResponse ok(String message) {
            return new ApiResponse(true, message);
        }
    }

    public record UserSummary(Long id, String fullName, String email, String profilePicture) {}
}
