package com.tripsync.service;

import com.tripsync.dto.DocumentDtos.DocumentResponse;
import com.tripsync.entity.TripDocument;
import com.tripsync.repository.TripDocumentRepository;
import com.tripsync.util.FileStorageService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
@RequiredArgsConstructor
public class DocumentService {

    private final TripDocumentRepository documentRepository;
    private final TripAccessService tripAccessService;
    private final FileStorageService fileStorageService;

    public List<DocumentResponse> getAll(Long tripId, Long userId) {
        tripAccessService.requireMember(tripId, userId);
        return documentRepository.findByTripIdOrderByUploadedAtDesc(tripId).stream()
                .map(this::toResponse).toList();
    }

    @Transactional
    public DocumentResponse upload(Long tripId, Long userId, MultipartFile file, String documentType) {
        var member = tripAccessService.requireMember(tripId, userId);
        String path = fileStorageService.store(file, "documents");

        TripDocument doc = TripDocument.builder()
                .trip(member.getTrip())
                .uploadedBy(member.getUser())
                .documentType(TripDocument.Type.valueOf(documentType))
                .fileName(file.getOriginalFilename())
                .filePath(path)
                .build();
        doc = documentRepository.save(doc);
        return toResponse(doc);
    }

    @Transactional
    public void delete(Long tripId, Long documentId, Long userId) {
        tripAccessService.requireMember(tripId, userId);
        documentRepository.deleteById(documentId);
    }

    private DocumentResponse toResponse(TripDocument d) {
        return new DocumentResponse(d.getId(), d.getDocumentType().name(), d.getFileName(), d.getFilePath(),
                d.getUploadedBy().getId(), d.getUploadedBy().getFullName(), d.getUploadedAt());
    }
}
