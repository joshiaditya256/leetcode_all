package com.tripsync.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class AuthDtos {

    public record RegisterRequest(
            @NotBlank(message = "Full name is required") String fullName,
            @NotBlank @Email(message = "A valid email is required") String email,
            @NotBlank @Size(min = 6, message = "Password must be at least 6 characters") String password,
            String phone
    ) {}

    public record LoginRequest(
            @NotBlank @Email String email,
            @NotBlank String password
    ) {}

    public record AuthResponse(
            String token,
            Long userId,
            String fullName,
            String email,
            String role
    ) {}

    public record ForgotPasswordRequest(@NotBlank @Email String email) {}

    public record ResetPasswordRequest(
            @NotBlank String token,
            @NotBlank @Size(min = 6, message = "Password must be at least 6 characters") String newPassword
    ) {}

    public record ChangePasswordRequest(
            @NotBlank String currentPassword,
            @NotBlank @Size(min = 6, message = "Password must be at least 6 characters") String newPassword
    ) {}

    public record UpdateProfileRequest(
            String fullName,
            String phone,
            String profilePicture,
            String preferences
    ) {}

    public record UserProfileResponse(
            Long id,
            String fullName,
            String email,
            String phone,
            String profilePicture,
            String role,
            boolean emailVerified,
            String preferences
    ) {}
}
