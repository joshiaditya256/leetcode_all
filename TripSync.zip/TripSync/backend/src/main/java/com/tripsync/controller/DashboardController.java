package com.tripsync.controller;

import com.tripsync.dto.DashboardDtos.*;
import com.tripsync.security.CustomUserDetails;
import com.tripsync.service.DashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/dashboard")
@RequiredArgsConstructor
public class DashboardController {

    private final DashboardService dashboardService;

    @GetMapping
    public ResponseEntity<UserDashboardResponse> userDashboard(@AuthenticationPrincipal CustomUserDetails principal) {
        return ResponseEntity.ok(dashboardService.getUserDashboard(principal.getId()));
    }

    @GetMapping("/trips/{tripId}")
    public ResponseEntity<TripDashboardResponse> tripDashboard(@AuthenticationPrincipal CustomUserDetails principal,
                                                                 @PathVariable Long tripId) {
        return ResponseEntity.ok(dashboardService.getTripDashboard(tripId, principal.getId()));
    }
}
