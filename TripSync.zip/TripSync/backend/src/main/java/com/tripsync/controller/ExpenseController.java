package com.tripsync.controller;

import com.tripsync.dto.CommonDtos.ApiResponse;
import com.tripsync.dto.ExpenseDtos.*;
import com.tripsync.security.CustomUserDetails;
import com.tripsync.service.ExpenseService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/trips/{tripId}/expenses")
@RequiredArgsConstructor
public class ExpenseController {

    private final ExpenseService expenseService;

    @GetMapping
    public ResponseEntity<List<ExpenseResponse>> getAll(@AuthenticationPrincipal CustomUserDetails principal,
                                                          @PathVariable Long tripId) {
        return ResponseEntity.ok(expenseService.getAll(tripId, principal.getId()));
    }

    @PostMapping
    public ResponseEntity<ExpenseResponse> create(@AuthenticationPrincipal CustomUserDetails principal,
                                                    @PathVariable Long tripId,
                                                    @Valid @RequestBody CreateExpenseRequest request) {
        return ResponseEntity.ok(expenseService.create(tripId, principal.getId(), request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> delete(@AuthenticationPrincipal CustomUserDetails principal,
                                               @PathVariable Long tripId, @PathVariable Long id) {
        expenseService.delete(tripId, id, principal.getId());
        return ResponseEntity.ok(ApiResponse.ok("Expense deleted"));
    }

    @GetMapping("/summary")
    public ResponseEntity<ExpenseSummaryResponse> summary(@AuthenticationPrincipal CustomUserDetails principal,
                                                            @PathVariable Long tripId) {
        return ResponseEntity.ok(expenseService.getSummary(tripId, principal.getId()));
    }
}
