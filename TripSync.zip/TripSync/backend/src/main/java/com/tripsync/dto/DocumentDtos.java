package com.tripsync.dto;

import java.time.LocalDateTime;

public class DocumentDtos {
    public record DocumentResponse(
            Long id,
            String documentType,
            String fileName,
            String filePath,
            Long uploadedById,
            String uploadedByName,
            LocalDateTime uploadedAt
    ) {}
}
