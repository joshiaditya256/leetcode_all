package com.tripsync.controller;

import com.tripsync.dto.CommonDtos.ApiResponse;
import com.tripsync.dto.DocumentDtos.DocumentResponse;
import com.tripsync.security.CustomUserDetails;
import com.tripsync.service.DocumentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/trips/{tripId}/documents")
@RequiredArgsConstructor
public class DocumentController {

    private final DocumentService documentService;

    @GetMapping
    public ResponseEntity<List<DocumentResponse>> getAll(@AuthenticationPrincipal CustomUserDetails principal,
                                                           @PathVariable Long tripId) {
        return ResponseEntity.ok(documentService.getAll(tripId, principal.getId()));
    }

    @PostMapping(consumes = "multipart/form-data")
    public ResponseEntity<DocumentResponse> upload(@AuthenticationPrincipal CustomUserDetails principal,
                                                     @PathVariable Long tripId,
                                                     @RequestParam("file") MultipartFile file,
                                                     @RequestParam String documentType) {
        return ResponseEntity.ok(documentService.upload(tripId, principal.getId(), file, documentType));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> delete(@AuthenticationPrincipal CustomUserDetails principal,
                                               @PathVariable Long tripId, @PathVariable Long id) {
        documentService.delete(tripId, id, principal.getId());
        return ResponseEntity.ok(ApiResponse.ok("Document deleted"));
    }
}
