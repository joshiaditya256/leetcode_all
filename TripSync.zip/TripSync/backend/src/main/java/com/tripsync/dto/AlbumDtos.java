package com.tripsync.dto;

import java.time.LocalDateTime;

public class AlbumDtos {

    public record AlbumCommentRequest(String comment) {}

    public record AlbumCommentResponse(Long id, Long userId, String userName, String comment, LocalDateTime createdAt) {}

    public record AlbumMediaResponse(
            Long id,
            String mediaType,
            String filePath,
            String caption,
            Integer dayNumber,
            Long uploadedById,
            String uploadedByName,
            long likeCount,
            boolean likedByMe,
            LocalDateTime createdAt
    ) {}
}
