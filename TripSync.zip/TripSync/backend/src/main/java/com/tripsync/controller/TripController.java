package com.tripsync.controller;

import com.tripsync.dto.CommonDtos.ApiResponse;
import com.tripsync.dto.TripDtos.*;
import com.tripsync.security.CustomUserDetails;
import com.tripsync.service.TripService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/trips")
@RequiredArgsConstructor
public class TripController {

    private final TripService tripService;

    @PostMapping
    public ResponseEntity<TripResponse> create(@AuthenticationPrincipal CustomUserDetails principal,
                                                @Valid @RequestBody CreateTripRequest request) {
        return ResponseEntity.ok(tripService.createTrip(principal.getId(), request));
    }

    @GetMapping
    public ResponseEntity<List<TripResponse>> myTrips(@AuthenticationPrincipal CustomUserDetails principal) {
        return ResponseEntity.ok(tripService.getMyTrips(principal.getId()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<TripResponse> get(@AuthenticationPrincipal CustomUserDetails principal,
                                             @PathVariable Long id) {
        return ResponseEntity.ok(tripService.getTrip(id, principal.getId()));
    }

    @PutMapping("/{id}")
    public ResponseEntity<TripResponse> update(@AuthenticationPrincipal CustomUserDetails principal,
                                                @PathVariable Long id, @RequestBody UpdateTripRequest request) {
        return ResponseEntity.ok(tripService.updateTrip(id, principal.getId(), request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> delete(@AuthenticationPrincipal CustomUserDetails principal,
                                               @PathVariable Long id) {
        tripService.deleteTrip(id, principal.getId());
        return ResponseEntity.ok(ApiResponse.ok("Trip deleted"));
    }

    @PostMapping("/{id}/archive")
    public ResponseEntity<ApiResponse> archive(@AuthenticationPrincipal CustomUserDetails principal,
                                                @PathVariable Long id) {
        tripService.archiveTrip(id, principal.getId());
        return ResponseEntity.ok(ApiResponse.ok("Trip archived"));
    }

    @PostMapping("/{id}/close")
    public ResponseEntity<ApiResponse> close(@AuthenticationPrincipal CustomUserDetails principal,
                                              @PathVariable Long id) {
        tripService.closeTrip(id, principal.getId());
        return ResponseEntity.ok(ApiResponse.ok("Trip closed"));
    }

    @PostMapping("/{id}/leave")
    public ResponseEntity<ApiResponse> leave(@AuthenticationPrincipal CustomUserDetails principal,
                                              @PathVariable Long id) {
        tripService.leaveTrip(id, principal.getId());
        return ResponseEntity.ok(ApiResponse.ok("You left the trip"));
    }
}
