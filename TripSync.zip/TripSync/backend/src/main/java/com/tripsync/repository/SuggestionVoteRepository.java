package com.tripsync.repository;

import com.tripsync.entity.SuggestionVote;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface SuggestionVoteRepository extends JpaRepository<SuggestionVote, Long> {
    Optional<SuggestionVote> findBySuggestionIdAndUserId(Long suggestionId, Long userId);
    long countBySuggestionId(Long suggestionId);
    List<SuggestionVote> findBySuggestionId(Long suggestionId);
    void deleteBySuggestionIdAndUserId(Long suggestionId, Long userId);
}
