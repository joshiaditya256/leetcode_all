package com.tripsync.dto;

import jakarta.validation.constraints.NotBlank;

import java.time.LocalDate;

public class ResponsibilityDtos {

    public record CreateResponsibilityRequest(
            @NotBlank String title,
            String description,
            Long assignedToUserId,
            LocalDate dueDate,
            String priority
    ) {}

    public record UpdateResponsibilityRequest(
            String title,
            String description,
            Long assignedToUserId,
            LocalDate dueDate,
            String status,
            String priority
    ) {}

    public record ResponsibilityResponse(
            Long id,
            String title,
            String description,
            Long assignedToUserId,
            String assignedToName,
            LocalDate dueDate,
            String status,
            String priority,
            LocalDate completionDate
    ) {}
}
