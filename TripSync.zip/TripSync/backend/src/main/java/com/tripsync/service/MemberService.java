package com.tripsync.service;

import com.tripsync.dto.MemberDtos.*;
import com.tripsync.entity.Notification;
import com.tripsync.entity.Trip;
import com.tripsync.entity.TripMember;
import com.tripsync.entity.User;
import com.tripsync.exception.BadRequestException;
import com.tripsync.exception.ForbiddenException;
import com.tripsync.exception.ResourceNotFoundException;
import com.tripsync.repository.TripMemberRepository;
import com.tripsync.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class MemberService {

    private final TripMemberRepository tripMemberRepository;
    private final UserRepository userRepository;
    private final TripAccessService tripAccessService;
    private final NotificationService notificationService;

    public List<MemberResponse> getMembers(Long tripId, Long userId) {
        tripAccessService.requireMember(tripId, userId);
        return tripMemberRepository.findByTripId(tripId).stream().map(this::toResponse).toList();
    }

    public List<MemberResponse> getPendingInvitations(Long userId) {
        return tripMemberRepository.findByUserId(userId).stream()
                .filter(m -> m.getStatus() == TripMember.Status.INVITED)
                .map(this::toResponse)
                .toList();
    }

    @Transactional
    public MemberResponse invite(Long tripId, Long inviterId, InviteMemberRequest request) {
        TripMember inviter = tripAccessService.requireCoordinator(tripId, inviterId);
        Trip trip = inviter.getTrip();

        User user = userRepository.findByEmail(request.email().toLowerCase())
                .orElseThrow(() -> new BadRequestException("No TripSync account found for that email"));

        if (tripMemberRepository.findByTripIdAndUserId(tripId, user.getId()).isPresent()) {
            throw new BadRequestException("This user is already invited to the trip");
        }

        TripMember member = TripMember.builder()
                .trip(trip).user(user)
                .role(TripMember.Role.MEMBER)
                .status(TripMember.Status.INVITED)
                .build();
        member = tripMemberRepository.save(member);

        notificationService.notify(user.getId(), Notification.Type.INVITATION_RECEIVED,
                "You've been invited to join \"" + trip.getName() + "\"", tripId);

        return toResponse(member);
    }

    @Transactional
    public MemberResponse respondToInvitation(Long tripId, Long userId, boolean accept) {
        TripMember member = tripMemberRepository.findByTripIdAndUserId(tripId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Invitation not found"));

        member.setStatus(accept ? TripMember.Status.ACCEPTED : TripMember.Status.DECLINED);
        if (accept) {
            member.setJoinedAt(LocalDateTime.now());
            notificationService.notify(member.getTrip().getCreatedBy().getId(), Notification.Type.MEMBER_JOINED,
                    member.getUser().getFullName() + " joined \"" + member.getTrip().getName() + "\"", tripId);
        }
        member = tripMemberRepository.save(member);
        return toResponse(member);
    }

    @Transactional
    public void removeMember(Long tripId, Long coordinatorId, Long memberUserId) {
        tripAccessService.requireCoordinator(tripId, coordinatorId);
        if (coordinatorId.equals(memberUserId)) {
            throw new ForbiddenException("The coordinator cannot remove themselves");
        }
        tripMemberRepository.deleteByTripIdAndUserId(tripId, memberUserId);
    }

    @Transactional
    public MemberResponse updateAvailability(Long tripId, Long userId, UpdateAvailabilityRequest request) {
        TripMember member = tripAccessService.requireMember(tripId, userId);
        member.setAvailability(request.availability());
        member = tripMemberRepository.save(member);
        return toResponse(member);
    }

    private MemberResponse toResponse(TripMember m) {
        User u = m.getUser();
        return new MemberResponse(m.getId(), u.getId(), u.getFullName(), u.getEmail(), u.getPhone(),
                u.getProfilePicture(), m.getRole().name(), m.getStatus().name(), m.getAvailability(),
                m.getTrip().getId(), m.getTrip().getName());
    }
}
