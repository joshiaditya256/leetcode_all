package com.tripsync.dto;

import jakarta.validation.constraints.NotBlank;

public class ChecklistDtos {

    public record CreateChecklistItemRequest(
            @NotBlank String itemName,
            Long assignedToUserId,
            Integer quantity
    ) {}

    public record UpdateChecklistItemRequest(
            String itemName,
            Long assignedToUserId,
            Integer quantity,
            String status
    ) {}

    public record ChecklistItemResponse(
            Long id,
            String itemName,
            Long assignedToUserId,
            String assignedToName,
            Integer quantity,
            String status
    ) {}
}
