package com.tripsync.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class ExpenseDtos {

    public record CreateExpenseRequest(
            @NotBlank String title,
            @NotBlank String category,
            @NotNull @Positive BigDecimal amount,
            String notes,
            List<Long> splitBetweenUserIds
    ) {}

    public record ExpenseSplitResponse(Long userId, String userName, BigDecimal shareAmount, boolean settled) {}

    public record ExpenseResponse(
            Long id,
            String title,
            String category,
            BigDecimal amount,
            Long paidById,
            String paidByName,
            String notes,
            LocalDateTime createdAt,
            List<ExpenseSplitResponse> splits
    ) {}

    public record BalanceEntry(Long userId, String userName, BigDecimal netBalance) {}

    public record SettlementTransfer(Long fromUserId, String fromUserName, Long toUserId, String toUserName, BigDecimal amount) {}

    public record ExpenseSummaryResponse(
            BigDecimal totalSpent,
            BigDecimal budget,
            BigDecimal remainingBudget,
            List<BalanceEntry> balances,
            List<SettlementTransfer> settlements
    ) {}
}
