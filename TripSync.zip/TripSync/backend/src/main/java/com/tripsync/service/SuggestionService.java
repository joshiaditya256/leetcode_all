package com.tripsync.service;

import com.tripsync.dto.SuggestionDtos.*;
import com.tripsync.entity.*;
import com.tripsync.exception.ResourceNotFoundException;
import com.tripsync.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class SuggestionService {

    private final SuggestionRepository suggestionRepository;
    private final SuggestionVoteRepository voteRepository;
    private final SuggestionCommentRepository commentRepository;
    private final ItineraryItemRepository itineraryItemRepository;
    private final TripAccessService tripAccessService;
    private final NotificationService notificationService;

    public List<SuggestionResponse> getAll(Long tripId, Long userId) {
        tripAccessService.requireMember(tripId, userId);
        return suggestionRepository.findByTripIdOrderByCreatedAtDesc(tripId).stream()
                .map(s -> toResponse(s, userId)).toList();
    }

    @Transactional
    public SuggestionResponse create(Long tripId, Long userId, CreateSuggestionRequest request) {
        var member = tripAccessService.requireMember(tripId, userId);
        Suggestion s = Suggestion.builder()
                .trip(member.getTrip())
                .type(Suggestion.Type.valueOf(request.type()))
                .title(request.title())
                .description(request.description())
                .suggestedBy(member.getUser())
                .status(Suggestion.Status.PENDING)
                .build();
        s = suggestionRepository.save(s);

        Suggestion finalS = s;
        notificationService.notify(member.getTrip().getCreatedBy().getId(), Notification.Type.SUGGESTION_ADDED,
                member.getUser().getFullName() + " suggested \"" + finalS.getTitle() + "\"", tripId);

        return toResponse(s, userId);
    }

    @Transactional
    public SuggestionResponse vote(Long tripId, Long suggestionId, Long userId) {
        var member = tripAccessService.requireMember(tripId, userId);
        Suggestion s = suggestionRepository.findById(suggestionId)
                .orElseThrow(() -> new ResourceNotFoundException("Suggestion not found"));

        var existing = voteRepository.findBySuggestionIdAndUserId(suggestionId, userId);
        if (existing.isPresent()) {
            voteRepository.delete(existing.get());
        } else {
            voteRepository.save(SuggestionVote.builder().suggestion(s).user(member.getUser()).build());
        }
        return toResponse(s, userId);
    }

    @Transactional
    public SuggestionCommentResponse addComment(Long tripId, Long suggestionId, Long userId, CommentRequest request) {
        var member = tripAccessService.requireMember(tripId, userId);
        Suggestion s = suggestionRepository.findById(suggestionId)
                .orElseThrow(() -> new ResourceNotFoundException("Suggestion not found"));

        SuggestionComment comment = SuggestionComment.builder()
                .suggestion(s).user(member.getUser()).comment(request.comment()).build();
        comment = commentRepository.save(comment);

        return new SuggestionCommentResponse(comment.getId(), comment.getUser().getId(),
                comment.getUser().getFullName(), comment.getComment(), comment.getCreatedAt());
    }

    public List<SuggestionCommentResponse> getComments(Long tripId, Long suggestionId, Long userId) {
        tripAccessService.requireMember(tripId, userId);
        return commentRepository.findBySuggestionIdOrderByCreatedAtAsc(suggestionId).stream()
                .map(c -> new SuggestionCommentResponse(c.getId(), c.getUser().getId(), c.getUser().getFullName(),
                        c.getComment(), c.getCreatedAt()))
                .toList();
    }

    @Transactional
    public SuggestionResponse approve(Long tripId, Long suggestionId, Long userId, boolean addToItinerary,
                                       Integer dayNumber, LocalDate date) {
        var coordinator = tripAccessService.requireCoordinator(tripId, userId);
        Suggestion s = suggestionRepository.findById(suggestionId)
                .orElseThrow(() -> new ResourceNotFoundException("Suggestion not found"));

        s.setStatus(Suggestion.Status.APPROVED);
        s = suggestionRepository.save(s);

        if (addToItinerary && dayNumber != null && date != null) {
            ItineraryItem item = ItineraryItem.builder()
                    .trip(coordinator.getTrip())
                    .dayNumber(dayNumber)
                    .date(date)
                    .activity(s.getTitle())
                    .notes(s.getDescription())
                    .createdBy(coordinator.getUser())
                    .build();
            itineraryItemRepository.save(item);
        }

        notificationService.notify(s.getSuggestedBy().getId(), Notification.Type.SUGGESTION_APPROVED,
                "Your suggestion \"" + s.getTitle() + "\" was approved", tripId);

        return toResponse(s, userId);
    }

    @Transactional
    public SuggestionResponse reject(Long tripId, Long suggestionId, Long userId) {
        tripAccessService.requireCoordinator(tripId, userId);
        Suggestion s = suggestionRepository.findById(suggestionId)
                .orElseThrow(() -> new ResourceNotFoundException("Suggestion not found"));
        s.setStatus(Suggestion.Status.REJECTED);
        s = suggestionRepository.save(s);
        return toResponse(s, userId);
    }

    private SuggestionResponse toResponse(Suggestion s, Long viewerId) {
        long votes = voteRepository.countBySuggestionId(s.getId());
        boolean votedByMe = voteRepository.findBySuggestionIdAndUserId(s.getId(), viewerId).isPresent();
        return new SuggestionResponse(
                s.getId(), s.getType().name(), s.getTitle(), s.getDescription(),
                s.getSuggestedBy().getId(), s.getSuggestedBy().getFullName(), s.getStatus().name(),
                votes, votedByMe, s.getCreatedAt()
        );
    }
}
