package com.tripsync.repository;

import com.tripsync.entity.TripMember;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TripMemberRepository extends JpaRepository<TripMember, Long> {
    List<TripMember> findByTripId(Long tripId);
    Optional<TripMember> findByTripIdAndUserId(Long tripId, Long userId);
    List<TripMember> findByUserId(Long userId);
    long countByTripIdAndStatus(Long tripId, TripMember.Status status);
    void deleteByTripIdAndUserId(Long tripId, Long userId);
}
