package com.tripsync.service;

import com.tripsync.dto.ExpenseDtos.*;
import com.tripsync.entity.*;
import com.tripsync.exception.BadRequestException;
import com.tripsync.exception.ResourceNotFoundException;
import com.tripsync.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

@Service
@RequiredArgsConstructor
public class ExpenseService {

    private final ExpenseRepository expenseRepository;
    private final TripMemberRepository tripMemberRepository;
    private final UserRepository userRepository;
    private final TripAccessService tripAccessService;
    private final NotificationService notificationService;

    public List<ExpenseResponse> getAll(Long tripId, Long userId) {
        tripAccessService.requireMember(tripId, userId);
        return expenseRepository.findByTripIdOrderByCreatedAtDesc(tripId).stream()
                .map(this::toResponse).toList();
    }

    @Transactional
    public ExpenseResponse create(Long tripId, Long userId, CreateExpenseRequest request) {
        var member = tripAccessService.requireMember(tripId, userId);
        Trip trip = member.getTrip();

        List<TripMember> allMembers = tripMemberRepository.findByTripId(tripId).stream()
                .filter(m -> m.getStatus() == TripMember.Status.ACCEPTED).toList();

        List<User> splitUsers;
        if (request.splitBetweenUserIds() != null && !request.splitBetweenUserIds().isEmpty()) {
            splitUsers = request.splitBetweenUserIds().stream()
                    .map(id -> userRepository.findById(id)
                            .orElseThrow(() -> new ResourceNotFoundException("User not found: " + id)))
                    .toList();
        } else {
            splitUsers = allMembers.stream().map(TripMember::getUser).toList();
        }
        if (splitUsers.isEmpty()) {
            throw new BadRequestException("Expense must be split between at least one member");
        }

        Expense expense = Expense.builder()
                .trip(trip)
                .title(request.title())
                .category(request.category())
                .amount(request.amount())
                .paidBy(member.getUser())
                .notes(request.notes())
                .build();

        BigDecimal share = request.amount().divide(BigDecimal.valueOf(splitUsers.size()), 2, RoundingMode.HALF_UP);
        List<ExpenseSplit> splits = new ArrayList<>();
        for (User u : splitUsers) {
            splits.add(ExpenseSplit.builder()
                    .expense(expense)
                    .user(u)
                    .shareAmount(share)
                    .settled(u.getId().equals(member.getUser().getId()))
                    .build());
        }
        expense.setSplits(splits);

        expense = expenseRepository.save(expense);

        for (TripMember m : allMembers) {
            notificationService.notify(m.getUser().getId(), Notification.Type.BUDGET_UPDATED,
                    member.getUser().getFullName() + " added expense \"" + expense.getTitle() + "\" (" + expense.getAmount() + ")", tripId);
        }

        return toResponse(expense);
    }

    @Transactional
    public void delete(Long tripId, Long expenseId, Long userId) {
        tripAccessService.requireMember(tripId, userId);
        expenseRepository.deleteById(expenseId);
    }

    public ExpenseSummaryResponse getSummary(Long tripId, Long userId) {
        var member = tripAccessService.requireMember(tripId, userId);
        Trip trip = member.getTrip();
        List<Expense> expenses = expenseRepository.findByTripIdOrderByCreatedAtDesc(tripId);

        BigDecimal totalSpent = expenses.stream().map(Expense::getAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal budget = trip.getBudget() != null ? trip.getBudget() : BigDecimal.ZERO;
        BigDecimal remaining = budget.subtract(totalSpent);

        // net balance per user: positive = is owed money, negative = owes money
        Map<Long, BigDecimal> net = new LinkedHashMap<>();
        Map<Long, String> names = new LinkedHashMap<>();
        for (Expense e : expenses) {
            net.merge(e.getPaidBy().getId(), e.getAmount(), BigDecimal::add);
            names.put(e.getPaidBy().getId(), e.getPaidBy().getFullName());
            for (ExpenseSplit s : e.getSplits()) {
                net.merge(s.getUser().getId(), s.getShareAmount().negate(), BigDecimal::add);
                names.put(s.getUser().getId(), s.getUser().getFullName());
            }
        }

        List<BalanceEntry> balances = net.entrySet().stream()
                .map(en -> new BalanceEntry(en.getKey(), names.get(en.getKey()), en.getValue()))
                .toList();

        List<SettlementTransfer> settlements = computeSettlements(balances);

        return new ExpenseSummaryResponse(totalSpent, budget, remaining, balances, settlements);
    }

    /** Simple greedy algorithm: match biggest debtor with biggest creditor repeatedly. */
    private List<SettlementTransfer> computeSettlements(List<BalanceEntry> balances) {
        List<BalanceEntry> creditors = new ArrayList<>();
        List<BalanceEntry> debtors = new ArrayList<>();
        for (BalanceEntry b : balances) {
            if (b.netBalance().compareTo(BigDecimal.ZERO) > 0) creditors.add(b);
            else if (b.netBalance().compareTo(BigDecimal.ZERO) < 0) debtors.add(b);
        }
        creditors.sort((a, c) -> c.netBalance().compareTo(a.netBalance()));
        debtors.sort((a, c) -> a.netBalance().compareTo(c.netBalance()));

        List<SettlementTransfer> result = new ArrayList<>();
        int ci = 0, di = 0;
        BigDecimal[] creditAmounts = creditors.stream().map(BalanceEntry::netBalance).toArray(BigDecimal[]::new);
        BigDecimal[] debtAmounts = debtors.stream().map(b -> b.netBalance().abs()).toArray(BigDecimal[]::new);

        while (ci < creditors.size() && di < debtors.size()) {
            BigDecimal amount = creditAmounts[ci].min(debtAmounts[di]);
            if (amount.compareTo(BigDecimal.valueOf(0.01)) >= 0) {
                result.add(new SettlementTransfer(
                        debtors.get(di).userId(), debtors.get(di).userName(),
                        creditors.get(ci).userId(), creditors.get(ci).userName(), amount));
            }
            creditAmounts[ci] = creditAmounts[ci].subtract(amount);
            debtAmounts[di] = debtAmounts[di].subtract(amount);
            if (creditAmounts[ci].compareTo(BigDecimal.valueOf(0.01)) < 0) ci++;
            if (debtAmounts[di].compareTo(BigDecimal.valueOf(0.01)) < 0) di++;
        }
        return result;
    }

    private ExpenseResponse toResponse(Expense e) {
        List<ExpenseSplitResponse> splits = e.getSplits().stream()
                .map(s -> new ExpenseSplitResponse(s.getUser().getId(), s.getUser().getFullName(), s.getShareAmount(), s.isSettled()))
                .toList();
        return new ExpenseResponse(e.getId(), e.getTitle(), e.getCategory(), e.getAmount(),
                e.getPaidBy().getId(), e.getPaidBy().getFullName(), e.getNotes(), e.getCreatedAt(), splits);
    }
}
