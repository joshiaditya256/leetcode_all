package com.tripsync.dto;

import java.time.LocalDateTime;

public class AdminDtos {

    public record AdminUserResponse(
            Long id, String fullName, String email, String role, boolean active,
            boolean emailVerified, LocalDateTime createdAt
    ) {}

    public record AdminTripResponse(
            Long id, String name, String destination, String status,
            String coordinatorName, int memberCount, LocalDateTime createdAt
    ) {}

    public record AnalyticsResponse(
            long totalUsers, long activeUsers, long totalTrips,
            long tripsInPlanning, long tripsOngoing, long tripsCompleted
    ) {}
}
