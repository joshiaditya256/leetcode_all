package com.tripsync.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public class TripDtos {

    public record CreateTripRequest(
            @NotBlank String name,
            @NotBlank String destination,
            String description,
            @NotNull LocalDate startDate,
            @NotNull LocalDate endDate,
            BigDecimal budget,
            List<String> memberEmails
    ) {}

    public record UpdateTripRequest(
            String name,
            String destination,
            String description,
            LocalDate startDate,
            LocalDate endDate,
            BigDecimal budget,
            String coverImage,
            String status
    ) {}

    public record TripResponse(
            Long id,
            String name,
            String destination,
            String description,
            LocalDate startDate,
            LocalDate endDate,
            BigDecimal budget,
            String coverImage,
            String status,
            Long createdById,
            String createdByName,
            String myRole,
            int memberCount,
            long daysUntilStart
    ) {}
}
