package com.tripsync.repository;

import com.tripsync.entity.TripDocument;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TripDocumentRepository extends JpaRepository<TripDocument, Long> {
    List<TripDocument> findByTripIdOrderByUploadedAtDesc(Long tripId);
}
