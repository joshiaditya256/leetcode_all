package com.tripsync.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

public class MemberDtos {

    public record InviteMemberRequest(@NotBlank @Email String email) {}

    public record UpdateAvailabilityRequest(String availability) {}

    public record MemberResponse(
            Long id,
            Long userId,
            String fullName,
            String email,
            String phone,
            String profilePicture,
            String role,
            String status,
            String availability,
            Long tripId,
            String tripName
    ) {}
}
