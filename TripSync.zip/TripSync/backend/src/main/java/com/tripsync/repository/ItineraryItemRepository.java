package com.tripsync.repository;

import com.tripsync.entity.ItineraryItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface ItineraryItemRepository extends JpaRepository<ItineraryItem, Long> {
    List<ItineraryItem> findByTripIdOrderByDayNumberAscTimeAsc(Long tripId);
    List<ItineraryItem> findByTripIdAndDateOrderByTimeAsc(Long tripId, LocalDate date);
}
