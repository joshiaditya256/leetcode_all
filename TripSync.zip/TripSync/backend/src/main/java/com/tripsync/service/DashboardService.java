package com.tripsync.service;

import com.tripsync.dto.DashboardDtos.*;
import com.tripsync.entity.Responsibility;
import com.tripsync.entity.Trip;
import com.tripsync.entity.TripMember;
import com.tripsync.repository.ResponsibilityRepository;
import com.tripsync.repository.TripMemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DashboardService {

    private final TripService tripService;
    private final MemberService memberService;
    private final ItineraryService itineraryService;
    private final ExpenseService expenseService;
    private final NotificationService notificationService;
    private final ResponsibilityRepository responsibilityRepository;
    private final TripAccessService tripAccessService;
    private final TripMemberRepository tripMemberRepository;

    public UserDashboardResponse getUserDashboard(Long userId) {
        var allTrips = tripService.getMyTrips(userId);
        var upcoming = allTrips.stream()
                .filter(t -> t.daysUntilStart() >= 0)
                .sorted(Comparator.comparingLong(t -> t.daysUntilStart()))
                .limit(5)
                .toList();

        return new UserDashboardResponse(
                upcoming,
                allTrips,
                memberService.getPendingInvitations(userId),
                notificationService.getRecent(userId),
                notificationService.countUnread(userId)
        );
    }

    public TripDashboardResponse getTripDashboard(Long tripId, Long userId) {
        Trip trip = tripAccessService.getTripOrThrow(tripId);
        tripAccessService.requireMember(tripId, userId);

        var tripResponse = tripService.getTrip(tripId, userId);
        var todaysPlan = itineraryService.getToday(tripId, userId);
        var expenseSummary = expenseService.getSummary(tripId, userId);

        List<TripMember> members = tripMemberRepository.findByTripId(tripId).stream()
                .filter(m -> m.getStatus() == TripMember.Status.ACCEPTED).toList();
        List<Responsibility> responsibilities = responsibilityRepository.findByTripIdOrderByDueDateAsc(tripId);

        Map<Long, List<Responsibility>> byAssignee = responsibilities.stream()
                .filter(r -> r.getAssignedTo() != null)
                .collect(Collectors.groupingBy(r -> r.getAssignedTo().getId()));

        List<MemberProgress> progress = members.stream().map(m -> {
            List<Responsibility> assigned = byAssignee.getOrDefault(m.getUser().getId(), List.of());
            long completed = assigned.stream().filter(r -> r.getStatus() == Responsibility.Status.COMPLETED).count();
            return new MemberProgress(m.getUser().getId(), m.getUser().getFullName(), assigned.size(), completed);
        }).toList();

        long daysUntilStart = ChronoUnit.DAYS.between(LocalDate.now(), trip.getStartDate());

        return new TripDashboardResponse(tripResponse, todaysPlan, progress, expenseSummary, daysUntilStart);
    }
}
