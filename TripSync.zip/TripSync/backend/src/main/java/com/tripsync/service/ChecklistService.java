package com.tripsync.service;

import com.tripsync.dto.ChecklistDtos.*;
import com.tripsync.entity.ChecklistItem;
import com.tripsync.entity.User;
import com.tripsync.exception.ResourceNotFoundException;
import com.tripsync.repository.ChecklistItemRepository;
import com.tripsync.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ChecklistService {

    private final ChecklistItemRepository checklistItemRepository;
    private final UserRepository userRepository;
    private final TripAccessService tripAccessService;

    public List<ChecklistItemResponse> getAll(Long tripId, Long userId) {
        tripAccessService.requireMember(tripId, userId);
        return checklistItemRepository.findByTripIdOrderByCreatedAtAsc(tripId).stream()
                .map(this::toResponse).toList();
    }

    @Transactional
    public ChecklistItemResponse create(Long tripId, Long userId, CreateChecklistItemRequest request) {
        var member = tripAccessService.requireMember(tripId, userId);

        User assignee = request.assignedToUserId() != null
                ? userRepository.findById(request.assignedToUserId())
                    .orElseThrow(() -> new ResourceNotFoundException("Assignee not found"))
                : null;

        ChecklistItem item = ChecklistItem.builder()
                .trip(member.getTrip())
                .itemName(request.itemName())
                .assignedTo(assignee)
                .quantity(request.quantity() != null ? request.quantity() : 1)
                .status(ChecklistItem.Status.PENDING)
                .createdBy(member.getUser())
                .build();
        item = checklistItemRepository.save(item);
        return toResponse(item);
    }

    @Transactional
    public ChecklistItemResponse update(Long tripId, Long itemId, Long userId, UpdateChecklistItemRequest request) {
        tripAccessService.requireMember(tripId, userId);
        ChecklistItem item = checklistItemRepository.findById(itemId)
                .orElseThrow(() -> new ResourceNotFoundException("Checklist item not found"));

        if (request.itemName() != null) item.setItemName(request.itemName());
        if (request.quantity() != null) item.setQuantity(request.quantity());
        if (request.status() != null) item.setStatus(ChecklistItem.Status.valueOf(request.status()));
        if (request.assignedToUserId() != null) {
            User assignee = userRepository.findById(request.assignedToUserId())
                    .orElseThrow(() -> new ResourceNotFoundException("Assignee not found"));
            item.setAssignedTo(assignee);
        }

        item = checklistItemRepository.save(item);
        return toResponse(item);
    }

    @Transactional
    public void delete(Long tripId, Long itemId, Long userId) {
        tripAccessService.requireMember(tripId, userId);
        checklistItemRepository.deleteById(itemId);
    }

    private ChecklistItemResponse toResponse(ChecklistItem item) {
        return new ChecklistItemResponse(
                item.getId(), item.getItemName(),
                item.getAssignedTo() != null ? item.getAssignedTo().getId() : null,
                item.getAssignedTo() != null ? item.getAssignedTo().getFullName() : null,
                item.getQuantity(), item.getStatus().name()
        );
    }
}
