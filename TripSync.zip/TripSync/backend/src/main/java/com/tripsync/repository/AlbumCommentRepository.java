package com.tripsync.repository;

import com.tripsync.entity.AlbumComment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AlbumCommentRepository extends JpaRepository<AlbumComment, Long> {
    List<AlbumComment> findByMediaIdOrderByCreatedAtAsc(Long mediaId);
}
