package com.tripsync.service;

import com.tripsync.dto.AdminDtos.*;
import com.tripsync.entity.Trip;
import com.tripsync.entity.User;
import com.tripsync.exception.ResourceNotFoundException;
import com.tripsync.repository.TripMemberRepository;
import com.tripsync.repository.TripRepository;
import com.tripsync.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AdminService {

    private final UserRepository userRepository;
    private final TripRepository tripRepository;
    private final TripMemberRepository tripMemberRepository;

    public List<AdminUserResponse> getAllUsers() {
        return userRepository.findAll().stream().map(u -> new AdminUserResponse(
                u.getId(), u.getFullName(), u.getEmail(), u.getRole().name(),
                u.isActive(), u.isEmailVerified(), u.getCreatedAt())).toList();
    }

    @Transactional
    public void setUserActive(Long userId, boolean active) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        user.setActive(active);
        userRepository.save(user);
    }

    @Transactional
    public void setUserRole(Long userId, String role) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        user.setRole(User.Role.valueOf(role));
        userRepository.save(user);
    }

    public List<AdminTripResponse> getAllTrips() {
        return tripRepository.findAll().stream().map(t -> {
            int memberCount = tripMemberRepository.findByTripId(t.getId()).size();
            return new AdminTripResponse(t.getId(), t.getName(), t.getDestination(), t.getStatus().name(),
                    t.getCreatedBy().getFullName(), memberCount, t.getCreatedAt());
        }).toList();
    }

    public AnalyticsResponse getAnalytics() {
        long totalUsers = userRepository.count();
        long activeUsers = userRepository.findAll().stream().filter(User::isActive).count();
        List<Trip> trips = tripRepository.findAll();
        long planning = trips.stream().filter(t -> t.getStatus() == Trip.Status.PLANNING).count();
        long ongoing = trips.stream().filter(t -> t.getStatus() == Trip.Status.ONGOING).count();
        long completed = trips.stream().filter(t -> t.getStatus() == Trip.Status.COMPLETED).count();
        return new AnalyticsResponse(totalUsers, activeUsers, trips.size(), planning, ongoing, completed);
    }
}
