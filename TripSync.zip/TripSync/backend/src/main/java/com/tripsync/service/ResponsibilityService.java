package com.tripsync.service;

import com.tripsync.dto.ResponsibilityDtos.*;
import com.tripsync.entity.Notification;
import com.tripsync.entity.Responsibility;
import com.tripsync.entity.Trip;
import com.tripsync.entity.User;
import com.tripsync.exception.ResourceNotFoundException;
import com.tripsync.repository.ResponsibilityRepository;
import com.tripsync.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ResponsibilityService {

    private final ResponsibilityRepository responsibilityRepository;
    private final UserRepository userRepository;
    private final TripAccessService tripAccessService;
    private final NotificationService notificationService;

    public List<ResponsibilityResponse> getAll(Long tripId, Long userId) {
        tripAccessService.requireMember(tripId, userId);
        return responsibilityRepository.findByTripIdOrderByDueDateAsc(tripId).stream()
                .map(this::toResponse).toList();
    }

    @Transactional
    public ResponsibilityResponse create(Long tripId, Long userId, CreateResponsibilityRequest request) {
        var member = tripAccessService.requireCoordinator(tripId, userId);
        Trip trip = member.getTrip();
        User creator = member.getUser();

        User assignee = null;
        if (request.assignedToUserId() != null) {
            assignee = userRepository.findById(request.assignedToUserId())
                    .orElseThrow(() -> new ResourceNotFoundException("Assignee not found"));
        }

        Responsibility r = Responsibility.builder()
                .trip(trip)
                .title(request.title())
                .description(request.description())
                .assignedTo(assignee)
                .dueDate(request.dueDate())
                .priority(request.priority() != null ? Responsibility.Priority.valueOf(request.priority()) : Responsibility.Priority.MEDIUM)
                .status(Responsibility.Status.PENDING)
                .createdBy(creator)
                .build();
        r = responsibilityRepository.save(r);

        if (assignee != null) {
            notificationService.notify(assignee.getId(), Notification.Type.TASK_ASSIGNED,
                    "You were assigned \"" + r.getTitle() + "\" for " + trip.getName(), tripId);
        }

        return toResponse(r);
    }

    @Transactional
    public ResponsibilityResponse update(Long tripId, Long responsibilityId, Long userId, UpdateResponsibilityRequest request) {
        tripAccessService.requireMember(tripId, userId);
        Responsibility r = responsibilityRepository.findById(responsibilityId)
                .orElseThrow(() -> new ResourceNotFoundException("Responsibility not found"));

        if (request.title() != null) r.setTitle(request.title());
        if (request.description() != null) r.setDescription(request.description());
        if (request.dueDate() != null) r.setDueDate(request.dueDate());
        if (request.priority() != null) r.setPriority(Responsibility.Priority.valueOf(request.priority()));
        if (request.assignedToUserId() != null) {
            User assignee = userRepository.findById(request.assignedToUserId())
                    .orElseThrow(() -> new ResourceNotFoundException("Assignee not found"));
            r.setAssignedTo(assignee);
            notificationService.notify(assignee.getId(), Notification.Type.TASK_ASSIGNED,
                    "You were assigned \"" + r.getTitle() + "\" for " + r.getTrip().getName(), tripId);
        }
        if (request.status() != null) {
            Responsibility.Status newStatus = Responsibility.Status.valueOf(request.status());
            r.setStatus(newStatus);
            if (newStatus == Responsibility.Status.COMPLETED) {
                r.setCompletionDate(LocalDate.now());
                notificationService.notify(r.getTrip().getCreatedBy().getId(), Notification.Type.TASK_COMPLETED,
                        "\"" + r.getTitle() + "\" was marked complete", tripId);
            }
        }

        r = responsibilityRepository.save(r);
        return toResponse(r);
    }

    @Transactional
    public void delete(Long tripId, Long responsibilityId, Long userId) {
        tripAccessService.requireCoordinator(tripId, userId);
        responsibilityRepository.deleteById(responsibilityId);
    }

    private ResponsibilityResponse toResponse(Responsibility r) {
        return new ResponsibilityResponse(
                r.getId(), r.getTitle(), r.getDescription(),
                r.getAssignedTo() != null ? r.getAssignedTo().getId() : null,
                r.getAssignedTo() != null ? r.getAssignedTo().getFullName() : null,
                r.getDueDate(), r.getStatus().name(), r.getPriority().name(), r.getCompletionDate()
        );
    }
}
