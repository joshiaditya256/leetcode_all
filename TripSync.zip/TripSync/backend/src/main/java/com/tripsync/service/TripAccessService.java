package com.tripsync.service;

import com.tripsync.entity.Trip;
import com.tripsync.entity.TripMember;
import com.tripsync.exception.ForbiddenException;
import com.tripsync.exception.ResourceNotFoundException;
import com.tripsync.repository.TripMemberRepository;
import com.tripsync.repository.TripRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * Shared helper used across trip-scoped modules (members, responsibilities, itinerary,
 * suggestions, checklist, expenses, album, documents) to resolve a trip and verify
 * that the current user is allowed to view/edit it.
 */
@Service
@RequiredArgsConstructor
public class TripAccessService {

    private final TripRepository tripRepository;
    private final TripMemberRepository tripMemberRepository;

    public Trip getTripOrThrow(Long tripId) {
        return tripRepository.findById(tripId)
                .orElseThrow(() -> new ResourceNotFoundException("Trip not found"));
    }

    /** Throws if the user is not an accepted member (or coordinator) of the trip. */
    public TripMember requireMember(Long tripId, Long userId) {
        TripMember member = tripMemberRepository.findByTripIdAndUserId(tripId, userId)
                .orElseThrow(() -> new ForbiddenException("You do not have access to this trip"));
        if (member.getStatus() != TripMember.Status.ACCEPTED) {
            throw new ForbiddenException("You have not accepted the invitation to this trip yet");
        }
        return member;
    }

    /** Throws unless the user is the trip's coordinator. */
    public TripMember requireCoordinator(Long tripId, Long userId) {
        TripMember member = requireMember(tripId, userId);
        if (member.getRole() != TripMember.Role.COORDINATOR) {
            throw new ForbiddenException("Only the trip coordinator can perform this action");
        }
        return member;
    }

    public boolean isMember(Long tripId, Long userId) {
        return tripMemberRepository.findByTripIdAndUserId(tripId, userId)
                .filter(m -> m.getStatus() == TripMember.Status.ACCEPTED)
                .isPresent();
    }
}
