package com.tripsync.controller;

import com.tripsync.dto.AlbumDtos.*;
import com.tripsync.dto.CommonDtos.ApiResponse;
import com.tripsync.security.CustomUserDetails;
import com.tripsync.service.AlbumService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/trips/{tripId}/album")
@RequiredArgsConstructor
public class AlbumController {

    private final AlbumService albumService;

    @GetMapping
    public ResponseEntity<List<AlbumMediaResponse>> getAll(@AuthenticationPrincipal CustomUserDetails principal,
                                                             @PathVariable Long tripId) {
        return ResponseEntity.ok(albumService.getAll(tripId, principal.getId()));
    }

    @PostMapping(consumes = "multipart/form-data")
    public ResponseEntity<AlbumMediaResponse> upload(@AuthenticationPrincipal CustomUserDetails principal,
                                                       @PathVariable Long tripId,
                                                       @RequestParam("file") MultipartFile file,
                                                       @RequestParam(required = false) String caption,
                                                       @RequestParam(required = false) Integer dayNumber) {
        return ResponseEntity.ok(albumService.upload(tripId, principal.getId(), file, caption, dayNumber));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> delete(@AuthenticationPrincipal CustomUserDetails principal,
                                               @PathVariable Long tripId, @PathVariable Long id) {
        albumService.delete(tripId, id, principal.getId());
        return ResponseEntity.ok(ApiResponse.ok("Media deleted"));
    }

    @PostMapping("/{id}/like")
    public ResponseEntity<AlbumMediaResponse> toggleLike(@AuthenticationPrincipal CustomUserDetails principal,
                                                           @PathVariable Long tripId, @PathVariable Long id) {
        return ResponseEntity.ok(albumService.toggleLike(tripId, id, principal.getId()));
    }

    @GetMapping("/{id}/comments")
    public ResponseEntity<List<AlbumCommentResponse>> getComments(@AuthenticationPrincipal CustomUserDetails principal,
                                                                    @PathVariable Long tripId, @PathVariable Long id) {
        return ResponseEntity.ok(albumService.getComments(tripId, id, principal.getId()));
    }

    @PostMapping("/{id}/comments")
    public ResponseEntity<AlbumCommentResponse> addComment(@AuthenticationPrincipal CustomUserDetails principal,
                                                             @PathVariable Long tripId, @PathVariable Long id,
                                                             @RequestBody AlbumCommentRequest request) {
        return ResponseEntity.ok(albumService.addComment(tripId, id, principal.getId(), request));
    }
}
