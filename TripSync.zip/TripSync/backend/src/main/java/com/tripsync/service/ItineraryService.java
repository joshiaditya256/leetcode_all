package com.tripsync.service;

import com.tripsync.dto.ItineraryDtos.*;
import com.tripsync.entity.ItineraryItem;
import com.tripsync.entity.Notification;
import com.tripsync.entity.Trip;
import com.tripsync.entity.User;
import com.tripsync.exception.ResourceNotFoundException;
import com.tripsync.repository.ItineraryItemRepository;
import com.tripsync.repository.TripMemberRepository;
import com.tripsync.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ItineraryService {

    private final ItineraryItemRepository itineraryItemRepository;
    private final UserRepository userRepository;
    private final TripAccessService tripAccessService;
    private final TripMemberRepository tripMemberRepository;
    private final NotificationService notificationService;

    public List<ItineraryItemResponse> getAll(Long tripId, Long userId) {
        tripAccessService.requireMember(tripId, userId);
        return itineraryItemRepository.findByTripIdOrderByDayNumberAscTimeAsc(tripId).stream()
                .map(this::toResponse).toList();
    }

    public List<ItineraryItemResponse> getToday(Long tripId, Long userId) {
        tripAccessService.requireMember(tripId, userId);
        return itineraryItemRepository.findByTripIdAndDateOrderByTimeAsc(tripId, LocalDate.now()).stream()
                .map(this::toResponse).toList();
    }

    @Transactional
    public ItineraryItemResponse create(Long tripId, Long userId, CreateItineraryItemRequest request) {
        var member = tripAccessService.requireCoordinator(tripId, userId);
        Trip trip = member.getTrip();

        User responsible = request.responsiblePersonId() != null
                ? userRepository.findById(request.responsiblePersonId())
                    .orElseThrow(() -> new ResourceNotFoundException("Responsible person not found"))
                : null;

        ItineraryItem item = ItineraryItem.builder()
                .trip(trip)
                .dayNumber(request.dayNumber())
                .date(request.date())
                .time(request.time())
                .activity(request.activity())
                .place(request.place())
                .notes(request.notes())
                .responsiblePerson(responsible)
                .createdBy(member.getUser())
                .build();
        item = itineraryItemRepository.save(item);

        notifyAllMembers(tripId, "Itinerary updated: \"" + item.getActivity() + "\" added for Day " + item.getDayNumber());

        return toResponse(item);
    }

    @Transactional
    public ItineraryItemResponse update(Long tripId, Long itemId, Long userId, UpdateItineraryItemRequest request) {
        tripAccessService.requireCoordinator(tripId, userId);
        ItineraryItem item = itineraryItemRepository.findById(itemId)
                .orElseThrow(() -> new ResourceNotFoundException("Itinerary item not found"));

        if (request.dayNumber() != null) item.setDayNumber(request.dayNumber());
        if (request.date() != null) item.setDate(request.date());
        if (request.time() != null) item.setTime(request.time());
        if (request.activity() != null) item.setActivity(request.activity());
        if (request.place() != null) item.setPlace(request.place());
        if (request.notes() != null) item.setNotes(request.notes());
        if (request.responsiblePersonId() != null) {
            User responsible = userRepository.findById(request.responsiblePersonId())
                    .orElseThrow(() -> new ResourceNotFoundException("Responsible person not found"));
            item.setResponsiblePerson(responsible);
        }

        item = itineraryItemRepository.save(item);
        notifyAllMembers(tripId, "Itinerary updated: \"" + item.getActivity() + "\"");
        return toResponse(item);
    }

    @Transactional
    public void delete(Long tripId, Long itemId, Long userId) {
        tripAccessService.requireCoordinator(tripId, userId);
        itineraryItemRepository.deleteById(itemId);
    }

    private void notifyAllMembers(Long tripId, String message) {
        tripMemberRepository.findByTripId(tripId).forEach(m ->
                notificationService.notify(m.getUser().getId(), Notification.Type.ITINERARY_CHANGED, message, tripId));
    }

    private ItineraryItemResponse toResponse(ItineraryItem item) {
        return new ItineraryItemResponse(
                item.getId(), item.getDayNumber(), item.getDate(), item.getTime(),
                item.getActivity(), item.getPlace(), item.getNotes(),
                item.getResponsiblePerson() != null ? item.getResponsiblePerson().getId() : null,
                item.getResponsiblePerson() != null ? item.getResponsiblePerson().getFullName() : null
        );
    }
}
