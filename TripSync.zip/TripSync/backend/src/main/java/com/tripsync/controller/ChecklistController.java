package com.tripsync.controller;

import com.tripsync.dto.ChecklistDtos.*;
import com.tripsync.dto.CommonDtos.ApiResponse;
import com.tripsync.security.CustomUserDetails;
import com.tripsync.service.ChecklistService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/trips/{tripId}/checklist")
@RequiredArgsConstructor
public class ChecklistController {

    private final ChecklistService checklistService;

    @GetMapping
    public ResponseEntity<List<ChecklistItemResponse>> getAll(@AuthenticationPrincipal CustomUserDetails principal,
                                                                @PathVariable Long tripId) {
        return ResponseEntity.ok(checklistService.getAll(tripId, principal.getId()));
    }

    @PostMapping
    public ResponseEntity<ChecklistItemResponse> create(@AuthenticationPrincipal CustomUserDetails principal,
                                                          @PathVariable Long tripId,
                                                          @Valid @RequestBody CreateChecklistItemRequest request) {
        return ResponseEntity.ok(checklistService.create(tripId, principal.getId(), request));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ChecklistItemResponse> update(@AuthenticationPrincipal CustomUserDetails principal,
                                                          @PathVariable Long tripId, @PathVariable Long id,
                                                          @RequestBody UpdateChecklistItemRequest request) {
        return ResponseEntity.ok(checklistService.update(tripId, id, principal.getId(), request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> delete(@AuthenticationPrincipal CustomUserDetails principal,
                                               @PathVariable Long tripId, @PathVariable Long id) {
        checklistService.delete(tripId, id, principal.getId());
        return ResponseEntity.ok(ApiResponse.ok("Checklist item deleted"));
    }
}
