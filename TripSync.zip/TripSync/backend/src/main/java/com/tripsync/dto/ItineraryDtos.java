package com.tripsync.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;
import java.time.LocalTime;

public class ItineraryDtos {

    public record CreateItineraryItemRequest(
            @NotNull Integer dayNumber,
            @NotNull LocalDate date,
            LocalTime time,
            @NotBlank String activity,
            String place,
            String notes,
            Long responsiblePersonId
    ) {}

    public record UpdateItineraryItemRequest(
            Integer dayNumber,
            LocalDate date,
            LocalTime time,
            String activity,
            String place,
            String notes,
            Long responsiblePersonId
    ) {}

    public record ItineraryItemResponse(
            Long id,
            Integer dayNumber,
            LocalDate date,
            LocalTime time,
            String activity,
            String place,
            String notes,
            Long responsiblePersonId,
            String responsiblePersonName
    ) {}
}
