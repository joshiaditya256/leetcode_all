package com.tripsync.service;

import com.tripsync.dto.AlbumDtos.*;
import com.tripsync.entity.AlbumComment;
import com.tripsync.entity.AlbumLike;
import com.tripsync.entity.AlbumMedia;
import com.tripsync.exception.ResourceNotFoundException;
import com.tripsync.repository.AlbumCommentRepository;
import com.tripsync.repository.AlbumLikeRepository;
import com.tripsync.repository.AlbumMediaRepository;
import com.tripsync.util.FileStorageService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AlbumService {

    private final AlbumMediaRepository albumMediaRepository;
    private final AlbumLikeRepository albumLikeRepository;
    private final AlbumCommentRepository albumCommentRepository;
    private final TripAccessService tripAccessService;
    private final FileStorageService fileStorageService;

    public List<AlbumMediaResponse> getAll(Long tripId, Long userId) {
        tripAccessService.requireMember(tripId, userId);
        return albumMediaRepository.findByTripIdOrderByDayNumberAscCreatedAtAsc(tripId).stream()
                .map(m -> toResponse(m, userId)).toList();
    }

    @Transactional
    public AlbumMediaResponse upload(Long tripId, Long userId, MultipartFile file, String caption, Integer dayNumber) {
        var member = tripAccessService.requireMember(tripId, userId);
        String path = fileStorageService.store(file, "album");

        String contentType = file.getContentType() == null ? "" : file.getContentType();
        AlbumMedia.Type type = contentType.startsWith("video") ? AlbumMedia.Type.VIDEO : AlbumMedia.Type.PHOTO;

        AlbumMedia media = AlbumMedia.builder()
                .trip(member.getTrip())
                .uploadedBy(member.getUser())
                .mediaType(type)
                .filePath(path)
                .caption(caption)
                .dayNumber(dayNumber)
                .build();
        media = albumMediaRepository.save(media);
        return toResponse(media, userId);
    }

    @Transactional
    public void delete(Long tripId, Long mediaId, Long userId) {
        tripAccessService.requireMember(tripId, userId);
        albumMediaRepository.deleteById(mediaId);
    }

    @Transactional
    public AlbumMediaResponse toggleLike(Long tripId, Long mediaId, Long userId) {
        var member = tripAccessService.requireMember(tripId, userId);
        AlbumMedia media = albumMediaRepository.findById(mediaId)
                .orElseThrow(() -> new ResourceNotFoundException("Media not found"));

        var existing = albumLikeRepository.findByMediaIdAndUserId(mediaId, userId);
        if (existing.isPresent()) {
            albumLikeRepository.delete(existing.get());
        } else {
            albumLikeRepository.save(AlbumLike.builder().media(media).user(member.getUser()).build());
        }
        return toResponse(media, userId);
    }

    @Transactional
    public AlbumCommentResponse addComment(Long tripId, Long mediaId, Long userId, AlbumCommentRequest request) {
        var member = tripAccessService.requireMember(tripId, userId);
        AlbumMedia media = albumMediaRepository.findById(mediaId)
                .orElseThrow(() -> new ResourceNotFoundException("Media not found"));

        AlbumComment comment = AlbumComment.builder()
                .media(media).user(member.getUser()).comment(request.comment()).build();
        comment = albumCommentRepository.save(comment);

        return new AlbumCommentResponse(comment.getId(), comment.getUser().getId(),
                comment.getUser().getFullName(), comment.getComment(), comment.getCreatedAt());
    }

    public List<AlbumCommentResponse> getComments(Long tripId, Long mediaId, Long userId) {
        tripAccessService.requireMember(tripId, userId);
        return albumCommentRepository.findByMediaIdOrderByCreatedAtAsc(mediaId).stream()
                .map(c -> new AlbumCommentResponse(c.getId(), c.getUser().getId(), c.getUser().getFullName(),
                        c.getComment(), c.getCreatedAt()))
                .toList();
    }

    private AlbumMediaResponse toResponse(AlbumMedia m, Long viewerId) {
        long likes = albumLikeRepository.countByMediaId(m.getId());
        boolean likedByMe = albumLikeRepository.findByMediaIdAndUserId(m.getId(), viewerId).isPresent();
        return new AlbumMediaResponse(m.getId(), m.getMediaType().name(), m.getFilePath(), m.getCaption(),
                m.getDayNumber(), m.getUploadedBy().getId(), m.getUploadedBy().getFullName(),
                likes, likedByMe, m.getCreatedAt());
    }
}
