package com.tripsync.repository;

import com.tripsync.entity.Trip;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TripRepository extends JpaRepository<Trip, Long> {

    @Query("select t from Trip t join TripMember tm on tm.trip = t " +
           "where tm.user.id = :userId and tm.status = com.tripsync.entity.TripMember.Status.ACCEPTED " +
           "order by t.startDate desc")
    List<Trip> findTripsForUser(@Param("userId") Long userId);

    List<Trip> findByCreatedById(Long userId);
}
