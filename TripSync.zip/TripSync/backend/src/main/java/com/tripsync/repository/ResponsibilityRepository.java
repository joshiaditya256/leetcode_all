package com.tripsync.repository;

import com.tripsync.entity.Responsibility;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ResponsibilityRepository extends JpaRepository<Responsibility, Long> {
    List<Responsibility> findByTripIdOrderByDueDateAsc(Long tripId);
    List<Responsibility> findByAssignedToIdAndStatusNot(Long userId, Responsibility.Status status);
}
