package com.tripsync.repository;

import com.tripsync.entity.Suggestion;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SuggestionRepository extends JpaRepository<Suggestion, Long> {
    List<Suggestion> findByTripIdOrderByCreatedAtDesc(Long tripId);
}
