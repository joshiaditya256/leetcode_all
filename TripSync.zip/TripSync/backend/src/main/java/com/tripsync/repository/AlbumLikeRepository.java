package com.tripsync.repository;

import com.tripsync.entity.AlbumLike;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AlbumLikeRepository extends JpaRepository<AlbumLike, Long> {
    Optional<AlbumLike> findByMediaIdAndUserId(Long mediaId, Long userId);
    long countByMediaId(Long mediaId);
    void deleteByMediaIdAndUserId(Long mediaId, Long userId);
}
