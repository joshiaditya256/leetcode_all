package com.tripsync.repository;

import com.tripsync.entity.SuggestionComment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SuggestionCommentRepository extends JpaRepository<SuggestionComment, Long> {
    List<SuggestionComment> findBySuggestionIdOrderByCreatedAtAsc(Long suggestionId);
}
