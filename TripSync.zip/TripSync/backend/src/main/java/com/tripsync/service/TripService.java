package com.tripsync.service;

import com.tripsync.dto.TripDtos.*;
import com.tripsync.entity.Notification;
import com.tripsync.entity.Trip;
import com.tripsync.entity.TripMember;
import com.tripsync.entity.User;
import com.tripsync.exception.ForbiddenException;
import com.tripsync.exception.ResourceNotFoundException;
import com.tripsync.repository.TripMemberRepository;
import com.tripsync.repository.TripRepository;
import com.tripsync.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TripService {

    private final TripRepository tripRepository;
    private final TripMemberRepository tripMemberRepository;
    private final UserRepository userRepository;
    private final TripAccessService tripAccessService;
    private final NotificationService notificationService;

    @Transactional
    public TripResponse createTrip(Long creatorId, CreateTripRequest request) {
        User creator = userRepository.findById(creatorId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Trip trip = Trip.builder()
                .name(request.name())
                .destination(request.destination())
                .description(request.description())
                .startDate(request.startDate())
                .endDate(request.endDate())
                .budget(request.budget())
                .status(Trip.Status.PLANNING)
                .createdBy(creator)
                .build();
        trip = tripRepository.save(trip);

        TripMember coordinator = TripMember.builder()
                .trip(trip)
                .user(creator)
                .role(TripMember.Role.COORDINATOR)
                .status(TripMember.Status.ACCEPTED)
                .build();
        coordinator.setJoinedAt(java.time.LocalDateTime.now());
        tripMemberRepository.save(coordinator);

        if (request.memberEmails() != null) {
            for (String email : request.memberEmails()) {
                inviteByEmail(trip, email, creator);
            }
        }

        return toResponse(trip, creatorId);
    }

    private void inviteByEmail(Trip trip, String email, User invitedBy) {
        userRepository.findByEmail(email.toLowerCase()).ifPresent(user -> {
            if (tripMemberRepository.findByTripIdAndUserId(trip.getId(), user.getId()).isPresent()) return;
            TripMember member = TripMember.builder()
                    .trip(trip).user(user)
                    .role(TripMember.Role.MEMBER)
                    .status(TripMember.Status.INVITED)
                    .build();
            tripMemberRepository.save(member);
            notificationService.notify(user.getId(), Notification.Type.INVITATION_RECEIVED,
                    invitedBy.getFullName() + " invited you to join \"" + trip.getName() + "\"", trip.getId());
        });
    }

    public List<TripResponse> getMyTrips(Long userId) {
        return tripRepository.findTripsForUser(userId).stream()
                .map(t -> toResponse(t, userId)).toList();
    }

    public TripResponse getTrip(Long tripId, Long userId) {
        Trip trip = tripAccessService.getTripOrThrow(tripId);
        tripAccessService.requireMember(tripId, userId);
        return toResponse(trip, userId);
    }

    @Transactional
    public TripResponse updateTrip(Long tripId, Long userId, UpdateTripRequest request) {
        tripAccessService.requireCoordinator(tripId, userId);
        Trip trip = tripAccessService.getTripOrThrow(tripId);

        if (request.name() != null) trip.setName(request.name());
        if (request.destination() != null) trip.setDestination(request.destination());
        if (request.description() != null) trip.setDescription(request.description());
        if (request.startDate() != null) trip.setStartDate(request.startDate());
        if (request.endDate() != null) trip.setEndDate(request.endDate());
        if (request.budget() != null) trip.setBudget(request.budget());
        if (request.coverImage() != null) trip.setCoverImage(request.coverImage());
        if (request.status() != null) trip.setStatus(Trip.Status.valueOf(request.status()));

        trip = tripRepository.save(trip);
        return toResponse(trip, userId);
    }

    @Transactional
    public void deleteTrip(Long tripId, Long userId) {
        tripAccessService.requireCoordinator(tripId, userId);
        tripRepository.deleteById(tripId);
    }

    @Transactional
    public void archiveTrip(Long tripId, Long userId) {
        tripAccessService.requireCoordinator(tripId, userId);
        Trip trip = tripAccessService.getTripOrThrow(tripId);
        trip.setStatus(Trip.Status.ARCHIVED);
        tripRepository.save(trip);
    }

    @Transactional
    public void closeTrip(Long tripId, Long userId) {
        tripAccessService.requireCoordinator(tripId, userId);
        Trip trip = tripAccessService.getTripOrThrow(tripId);
        trip.setStatus(Trip.Status.COMPLETED);
        tripRepository.save(trip);
    }

    @Transactional
    public void leaveTrip(Long tripId, Long userId) {
        TripMember member = tripMemberRepository.findByTripIdAndUserId(tripId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("You are not a member of this trip"));
        if (member.getRole() == TripMember.Role.COORDINATOR) {
            throw new ForbiddenException("The coordinator cannot leave the trip. Delete the trip instead.");
        }
        tripMemberRepository.delete(member);
    }

    private TripResponse toResponse(Trip trip, Long viewerId) {
        int memberCount = (int) tripMemberRepository.countByTripIdAndStatus(trip.getId(), TripMember.Status.ACCEPTED);
        String myRole = tripMemberRepository.findByTripIdAndUserId(trip.getId(), viewerId)
                .map(m -> m.getRole().name()).orElse(null);
        long daysUntilStart = ChronoUnit.DAYS.between(LocalDate.now(), trip.getStartDate());

        return new TripResponse(
                trip.getId(), trip.getName(), trip.getDestination(), trip.getDescription(),
                trip.getStartDate(), trip.getEndDate(), trip.getBudget(), trip.getCoverImage(),
                trip.getStatus().name(), trip.getCreatedBy().getId(), trip.getCreatedBy().getFullName(),
                myRole, memberCount, daysUntilStart
        );
    }
}
