package com.tripsync.controller;

import com.tripsync.dto.SuggestionDtos.*;
import com.tripsync.security.CustomUserDetails;
import com.tripsync.service.SuggestionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/trips/{tripId}/suggestions")
@RequiredArgsConstructor
public class SuggestionController {

    private final SuggestionService suggestionService;

    @GetMapping
    public ResponseEntity<List<SuggestionResponse>> getAll(@AuthenticationPrincipal CustomUserDetails principal,
                                                             @PathVariable Long tripId) {
        return ResponseEntity.ok(suggestionService.getAll(tripId, principal.getId()));
    }

    @PostMapping
    public ResponseEntity<SuggestionResponse> create(@AuthenticationPrincipal CustomUserDetails principal,
                                                       @PathVariable Long tripId,
                                                       @Valid @RequestBody CreateSuggestionRequest request) {
        return ResponseEntity.ok(suggestionService.create(tripId, principal.getId(), request));
    }

    @PostMapping("/{id}/vote")
    public ResponseEntity<SuggestionResponse> vote(@AuthenticationPrincipal CustomUserDetails principal,
                                                     @PathVariable Long tripId, @PathVariable Long id) {
        return ResponseEntity.ok(suggestionService.vote(tripId, id, principal.getId()));
    }

    @GetMapping("/{id}/comments")
    public ResponseEntity<List<SuggestionCommentResponse>> getComments(@AuthenticationPrincipal CustomUserDetails principal,
                                                                         @PathVariable Long tripId, @PathVariable Long id) {
        return ResponseEntity.ok(suggestionService.getComments(tripId, id, principal.getId()));
    }

    @PostMapping("/{id}/comments")
    public ResponseEntity<SuggestionCommentResponse> addComment(@AuthenticationPrincipal CustomUserDetails principal,
                                                                  @PathVariable Long tripId, @PathVariable Long id,
                                                                  @Valid @RequestBody CommentRequest request) {
        return ResponseEntity.ok(suggestionService.addComment(tripId, id, principal.getId(), request));
    }

    @PostMapping("/{id}/approve")
    public ResponseEntity<SuggestionResponse> approve(@AuthenticationPrincipal CustomUserDetails principal,
                                                        @PathVariable Long tripId, @PathVariable Long id,
                                                        @RequestParam(defaultValue = "false") boolean addToItinerary,
                                                        @RequestParam(required = false) Integer dayNumber,
                                                        @RequestParam(required = false)
                                                        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return ResponseEntity.ok(suggestionService.approve(tripId, id, principal.getId(), addToItinerary, dayNumber, date));
    }

    @PostMapping("/{id}/reject")
    public ResponseEntity<SuggestionResponse> reject(@AuthenticationPrincipal CustomUserDetails principal,
                                                       @PathVariable Long tripId, @PathVariable Long id) {
        return ResponseEntity.ok(suggestionService.reject(tripId, id, principal.getId()));
    }
}
