package com.tripsync.repository;

import com.tripsync.entity.ExpenseSplit;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ExpenseSplitRepository extends JpaRepository<ExpenseSplit, Long> {
    List<ExpenseSplit> findByExpenseTripId(Long tripId);
    List<ExpenseSplit> findByUserIdAndExpenseTripId(Long userId, Long tripId);
}
