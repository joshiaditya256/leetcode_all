package com.tripsync.controller;

import com.tripsync.dto.AdminDtos.*;
import com.tripsync.dto.CommonDtos.ApiResponse;
import com.tripsync.service.AdminService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** All endpoints here require ROLE_ADMIN (enforced in SecurityConfig). */
@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminController {

    private final AdminService adminService;

    @GetMapping("/users")
    public ResponseEntity<List<AdminUserResponse>> getUsers() {
        return ResponseEntity.ok(adminService.getAllUsers());
    }

    @PatchMapping("/users/{id}/activate")
    public ResponseEntity<ApiResponse> activate(@PathVariable Long id) {
        adminService.setUserActive(id, true);
        return ResponseEntity.ok(ApiResponse.ok("User activated"));
    }

    @PatchMapping("/users/{id}/deactivate")
    public ResponseEntity<ApiResponse> deactivate(@PathVariable Long id) {
        adminService.setUserActive(id, false);
        return ResponseEntity.ok(ApiResponse.ok("User deactivated"));
    }

    @PatchMapping("/users/{id}/role")
    public ResponseEntity<ApiResponse> setRole(@PathVariable Long id, @RequestParam String role) {
        adminService.setUserRole(id, role);
        return ResponseEntity.ok(ApiResponse.ok("Role updated"));
    }

    @GetMapping("/trips")
    public ResponseEntity<List<AdminTripResponse>> getTrips() {
        return ResponseEntity.ok(adminService.getAllTrips());
    }

    @GetMapping("/analytics")
    public ResponseEntity<AnalyticsResponse> analytics() {
        return ResponseEntity.ok(adminService.getAnalytics());
    }
}
