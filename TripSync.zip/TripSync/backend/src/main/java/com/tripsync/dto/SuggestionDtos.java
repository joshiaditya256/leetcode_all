package com.tripsync.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDateTime;

public class SuggestionDtos {

    public record CreateSuggestionRequest(
            @NotNull String type,
            @NotBlank String title,
            String description
    ) {}

    public record CommentRequest(@NotBlank String comment) {}

    public record SuggestionResponse(
            Long id,
            String type,
            String title,
            String description,
            Long suggestedById,
            String suggestedByName,
            String status,
            long voteCount,
            boolean votedByMe,
            LocalDateTime createdAt
    ) {}

    public record SuggestionCommentResponse(
            Long id,
            Long userId,
            String userName,
            String comment,
            LocalDateTime createdAt
    ) {}
}
