package com.tripsync.dto;

import com.tripsync.dto.ExpenseDtos.ExpenseSummaryResponse;
import com.tripsync.dto.ItineraryDtos.ItineraryItemResponse;
import com.tripsync.dto.MemberDtos.MemberResponse;
import com.tripsync.dto.NotificationDtos.NotificationResponse;
import com.tripsync.dto.TripDtos.TripResponse;

import java.util.List;

public class DashboardDtos {

    public record UserDashboardResponse(
            List<TripResponse> upcomingTrips,
            List<TripResponse> allTrips,
            List<MemberResponse> pendingInvitations,
            List<NotificationResponse> recentNotifications,
            long unreadNotificationCount
    ) {}

    public record MemberProgress(Long userId, String userName, long totalTasks, long completedTasks) {}

    public record TripDashboardResponse(
            TripResponse trip,
            List<ItineraryItemResponse> todaysPlan,
            List<MemberProgress> memberProgress,
            ExpenseSummaryResponse expenseSummary,
            long daysUntilStart
    ) {}
}
