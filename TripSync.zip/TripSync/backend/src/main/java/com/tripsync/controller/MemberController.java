package com.tripsync.controller;

import com.tripsync.dto.CommonDtos.ApiResponse;
import com.tripsync.dto.MemberDtos.*;
import com.tripsync.security.CustomUserDetails;
import com.tripsync.service.MemberService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/trips/{tripId}/members")
@RequiredArgsConstructor
public class MemberController {

    private final MemberService memberService;

    @GetMapping
    public ResponseEntity<List<MemberResponse>> getMembers(@AuthenticationPrincipal CustomUserDetails principal,
                                                             @PathVariable Long tripId) {
        return ResponseEntity.ok(memberService.getMembers(tripId, principal.getId()));
    }

    @PostMapping("/invite")
    public ResponseEntity<MemberResponse> invite(@AuthenticationPrincipal CustomUserDetails principal,
                                                   @PathVariable Long tripId,
                                                   @Valid @RequestBody InviteMemberRequest request) {
        return ResponseEntity.ok(memberService.invite(tripId, principal.getId(), request));
    }

    @PostMapping("/respond")
    public ResponseEntity<MemberResponse> respond(@AuthenticationPrincipal CustomUserDetails principal,
                                                    @PathVariable Long tripId,
                                                    @RequestParam boolean accept) {
        return ResponseEntity.ok(memberService.respondToInvitation(tripId, principal.getId(), accept));
    }

    @DeleteMapping("/{memberUserId}")
    public ResponseEntity<ApiResponse> remove(@AuthenticationPrincipal CustomUserDetails principal,
                                               @PathVariable Long tripId, @PathVariable Long memberUserId) {
        memberService.removeMember(tripId, principal.getId(), memberUserId);
        return ResponseEntity.ok(ApiResponse.ok("Member removed"));
    }

    @PutMapping("/availability")
    public ResponseEntity<MemberResponse> updateAvailability(@AuthenticationPrincipal CustomUserDetails principal,
                                                               @PathVariable Long tripId,
                                                               @RequestBody UpdateAvailabilityRequest request) {
        return ResponseEntity.ok(memberService.updateAvailability(tripId, principal.getId(), request));
    }
}
