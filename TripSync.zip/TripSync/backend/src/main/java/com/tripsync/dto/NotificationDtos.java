package com.tripsync.dto;

import com.tripsync.entity.Notification;

import java.time.LocalDateTime;

public class NotificationDtos {
    public record NotificationResponse(
            Long id, String type, String message, Long relatedTripId, boolean isRead, LocalDateTime createdAt
    ) {
        public static NotificationResponse from(Notification n) {
            return new NotificationResponse(n.getId(), n.getType().name(), n.getMessage(),
                    n.getRelatedTripId(), n.isRead(), n.getCreatedAt());
        }
    }
}
