package com.tripsync.controller;

import com.tripsync.dto.CommonDtos.ApiResponse;
import com.tripsync.dto.ItineraryDtos.*;
import com.tripsync.security.CustomUserDetails;
import com.tripsync.service.ItineraryService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/trips/{tripId}/itinerary")
@RequiredArgsConstructor
public class ItineraryController {

    private final ItineraryService itineraryService;

    @GetMapping
    public ResponseEntity<List<ItineraryItemResponse>> getAll(@AuthenticationPrincipal CustomUserDetails principal,
                                                                @PathVariable Long tripId) {
        return ResponseEntity.ok(itineraryService.getAll(tripId, principal.getId()));
    }

    @GetMapping("/today")
    public ResponseEntity<List<ItineraryItemResponse>> getToday(@AuthenticationPrincipal CustomUserDetails principal,
                                                                  @PathVariable Long tripId) {
        return ResponseEntity.ok(itineraryService.getToday(tripId, principal.getId()));
    }

    @PostMapping
    public ResponseEntity<ItineraryItemResponse> create(@AuthenticationPrincipal CustomUserDetails principal,
                                                          @PathVariable Long tripId,
                                                          @Valid @RequestBody CreateItineraryItemRequest request) {
        return ResponseEntity.ok(itineraryService.create(tripId, principal.getId(), request));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ItineraryItemResponse> update(@AuthenticationPrincipal CustomUserDetails principal,
                                                          @PathVariable Long tripId, @PathVariable Long id,
                                                          @RequestBody UpdateItineraryItemRequest request) {
        return ResponseEntity.ok(itineraryService.update(tripId, id, principal.getId(), request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> delete(@AuthenticationPrincipal CustomUserDetails principal,
                                               @PathVariable Long tripId, @PathVariable Long id) {
        itineraryService.delete(tripId, id, principal.getId());
        return ResponseEntity.ok(ApiResponse.ok("Itinerary item deleted"));
    }
}
