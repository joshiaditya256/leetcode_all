package com.tripsync.controller;

import com.tripsync.dto.CommonDtos.ApiResponse;
import com.tripsync.dto.ResponsibilityDtos.*;
import com.tripsync.security.CustomUserDetails;
import com.tripsync.service.ResponsibilityService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/trips/{tripId}/responsibilities")
@RequiredArgsConstructor
public class ResponsibilityController {

    private final ResponsibilityService responsibilityService;

    @GetMapping
    public ResponseEntity<List<ResponsibilityResponse>> getAll(@AuthenticationPrincipal CustomUserDetails principal,
                                                                 @PathVariable Long tripId) {
        return ResponseEntity.ok(responsibilityService.getAll(tripId, principal.getId()));
    }

    @PostMapping
    public ResponseEntity<ResponsibilityResponse> create(@AuthenticationPrincipal CustomUserDetails principal,
                                                           @PathVariable Long tripId,
                                                           @Valid @RequestBody CreateResponsibilityRequest request) {
        return ResponseEntity.ok(responsibilityService.create(tripId, principal.getId(), request));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ResponsibilityResponse> update(@AuthenticationPrincipal CustomUserDetails principal,
                                                           @PathVariable Long tripId, @PathVariable Long id,
                                                           @RequestBody UpdateResponsibilityRequest request) {
        return ResponseEntity.ok(responsibilityService.update(tripId, id, principal.getId(), request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> delete(@AuthenticationPrincipal CustomUserDetails principal,
                                               @PathVariable Long tripId, @PathVariable Long id) {
        responsibilityService.delete(tripId, id, principal.getId());
        return ResponseEntity.ok(ApiResponse.ok("Responsibility deleted"));
    }
}
