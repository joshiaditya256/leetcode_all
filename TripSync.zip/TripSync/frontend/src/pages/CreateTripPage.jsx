import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import api from '../api/axios.js'

export default function CreateTripPage() {
  const navigate = useNavigate()
  const [form, setForm] = useState({
    name: '', destination: '', description: '', startDate: '', endDate: '', budget: '', memberEmailsText: '',
  })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      const memberEmails = form.memberEmailsText
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean)
      const payload = {
        name: form.name,
        destination: form.destination,
        description: form.description,
        startDate: form.startDate,
        endDate: form.endDate,
        budget: form.budget ? Number(form.budget) : null,
        memberEmails,
      }
      const res = await api.post('/trips', payload)
      navigate(`/trips/${res.data.id}`)
    } catch (err) {
      setError(err.response?.data?.message || 'Could not create trip')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container py-4" style={{ maxWidth: 640 }}>
      <div className="ts-card bg-white p-4 p-md-5">
        <h2 className="mb-4">Create a Trip</h2>
        {error && <div className="alert alert-danger">{error}</div>}
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label className="form-label">Trip Name</label>
            <input className="form-control" required
              value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </div>
          <div className="mb-3">
            <label className="form-label">Destination</label>
            <input className="form-control" required
              value={form.destination} onChange={(e) => setForm({ ...form, destination: e.target.value })} />
          </div>
          <div className="mb-3">
            <label className="form-label">Description</label>
            <textarea className="form-control" rows={3}
              value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          </div>
          <div className="row g-3 mb-3">
            <div className="col-6">
              <label className="form-label">Start Date</label>
              <input type="date" className="form-control" required
                value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} />
            </div>
            <div className="col-6">
              <label className="form-label">End Date</label>
              <input type="date" className="form-control" required
                value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} />
            </div>
          </div>
          <div className="mb-3">
            <label className="form-label">Budget (optional)</label>
            <input type="number" min="0" step="0.01" className="form-control"
              value={form.budget} onChange={(e) => setForm({ ...form, budget: e.target.value })} />
          </div>
          <div className="mb-4">
            <label className="form-label">Invite Members (comma-separated emails, optional)</label>
            <input className="form-control" placeholder="friend1@email.com, friend2@email.com"
              value={form.memberEmailsText} onChange={(e) => setForm({ ...form, memberEmailsText: e.target.value })} />
            <div className="form-text">They must already have a TripSync account to be invited now — you can invite more later.</div>
          </div>
          <button type="submit" className="btn btn-primary w-100" disabled={loading}>
            {loading ? 'Creating…' : 'Create Trip'}
          </button>
        </form>
      </div>
    </div>
  )
}
