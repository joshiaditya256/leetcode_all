import { useEffect, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import api from '../api/axios.js'

export default function VerifyEmailPage() {
  const [searchParams] = useSearchParams()
  const token = searchParams.get('token') || ''
  const [status, setStatus] = useState('verifying')

  useEffect(() => {
    if (!token) {
      setStatus('missing')
      return
    }
    api.get('/auth/verify-email', { params: { token } })
      .then(() => setStatus('success'))
      .catch(() => setStatus('error'))
  }, [token])

  return (
    <div className="container py-5 text-center" style={{ maxWidth: 480 }}>
      <div className="ts-card bg-white p-5">
        {status === 'verifying' && <p>Verifying your email…</p>}
        {status === 'missing' && <p className="text-warning">Missing verification token.</p>}
        {status === 'success' && <p className="text-success fw-bold">Your email has been verified!</p>}
        {status === 'error' && <p className="text-danger">This verification link is invalid or expired.</p>}
        <Link to="/login" className="btn btn-primary mt-3">Go to Login</Link>
      </div>
    </div>
  )
}
