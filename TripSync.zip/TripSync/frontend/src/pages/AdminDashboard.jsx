import { useEffect, useState } from 'react'
import api from '../api/axios.js'

export default function AdminDashboard() {
  const [tab, setTab] = useState('users')
  const [users, setUsers] = useState([])
  const [trips, setTrips] = useState([])
  const [analytics, setAnalytics] = useState(null)

  const loadUsers = () => api.get('/admin/users').then((res) => setUsers(res.data))
  const loadTrips = () => api.get('/admin/trips').then((res) => setTrips(res.data))
  const loadAnalytics = () => api.get('/admin/analytics').then((res) => setAnalytics(res.data))

  useEffect(() => { loadUsers(); loadTrips(); loadAnalytics() }, [])

  const toggleActive = async (user) => {
    await api.patch(`/admin/users/${user.id}/${user.active ? 'deactivate' : 'activate'}`)
    loadUsers()
  }

  return (
    <div className="container py-4">
      <h2 className="mb-4">Admin Dashboard</h2>

      {analytics && (
        <div className="row g-3 mb-4">
          {[
            ['Total Users', analytics.totalUsers],
            ['Active Users', analytics.activeUsers],
            ['Total Trips', analytics.totalTrips],
            ['Ongoing Trips', analytics.tripsOngoing],
          ].map(([label, value]) => (
            <div className="col-6 col-md-3" key={label}>
              <div className="ts-card bg-white p-3 text-center">
                <div className="fs-3 fw-bold">{value}</div>
                <div className="text-muted small">{label}</div>
              </div>
            </div>
          ))}
        </div>
      )}

      <ul className="nav nav-tabs mb-3">
        <li className="nav-item">
          <button className={`nav-link ${tab === 'users' ? 'active' : ''}`} onClick={() => setTab('users')}>Users</button>
        </li>
        <li className="nav-item">
          <button className={`nav-link ${tab === 'trips' ? 'active' : ''}`} onClick={() => setTab('trips')}>Trips</button>
        </li>
      </ul>

      {tab === 'users' && (
        <div className="table-responsive ts-card bg-white p-3">
          <table className="table align-middle mb-0">
            <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Verified</th><th></th></tr></thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id}>
                  <td>{u.fullName}</td>
                  <td>{u.email}</td>
                  <td>{u.role}</td>
                  <td>{u.active ? <span className="badge bg-success">Active</span> : <span className="badge bg-secondary">Inactive</span>}</td>
                  <td>{u.emailVerified ? '✔' : '—'}</td>
                  <td>
                    <button className="btn btn-sm btn-outline-danger" onClick={() => toggleActive(u)}>
                      {u.active ? 'Deactivate' : 'Activate'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'trips' && (
        <div className="table-responsive ts-card bg-white p-3">
          <table className="table align-middle mb-0">
            <thead><tr><th>Name</th><th>Destination</th><th>Status</th><th>Coordinator</th><th>Members</th></tr></thead>
            <tbody>
              {trips.map((t) => (
                <tr key={t.id}>
                  <td>{t.name}</td>
                  <td>{t.destination}</td>
                  <td><span className="badge bg-primary badge-status">{t.status.toLowerCase()}</span></td>
                  <td>{t.coordinatorName}</td>
                  <td>{t.memberCount}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
