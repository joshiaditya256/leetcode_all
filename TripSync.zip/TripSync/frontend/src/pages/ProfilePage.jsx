import { useEffect, useState } from 'react'
import api from '../api/axios.js'
import { useAuth } from '../context/AuthContext.jsx'

export default function ProfilePage() {
  const { refreshProfile } = useAuth()
  const [profile, setProfile] = useState(null)
  const [form, setForm] = useState({ fullName: '', phone: '', preferences: '' })
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')

  const [pwForm, setPwForm] = useState({ currentPassword: '', newPassword: '' })
  const [pwMessage, setPwMessage] = useState('')
  const [pwError, setPwError] = useState('')

  useEffect(() => {
    api.get('/auth/me').then((res) => {
      setProfile(res.data)
      setForm({ fullName: res.data.fullName, phone: res.data.phone || '', preferences: res.data.preferences || '' })
    })
  }, [])

  const saveProfile = async (e) => {
    e.preventDefault()
    setMessage('')
    setError('')
    try {
      await api.put('/auth/me', form)
      await refreshProfile()
      setMessage('Profile updated')
    } catch (err) {
      setError(err.response?.data?.message || 'Could not update profile')
    }
  }

  const changePassword = async (e) => {
    e.preventDefault()
    setPwMessage('')
    setPwError('')
    try {
      await api.post('/auth/change-password', pwForm)
      setPwMessage('Password changed')
      setPwForm({ currentPassword: '', newPassword: '' })
    } catch (err) {
      setPwError(err.response?.data?.message || 'Could not change password')
    }
  }

  if (!profile) return <div className="container py-5 text-center">Loading…</div>

  return (
    <div className="container py-4" style={{ maxWidth: 640 }}>
      <h2 className="mb-4">Profile</h2>

      <div className="ts-card bg-white p-4 mb-4">
        <h5 className="mb-3">Personal Details</h5>
        {message && <div className="alert alert-success">{message}</div>}
        {error && <div className="alert alert-danger">{error}</div>}
        <form onSubmit={saveProfile}>
          <div className="mb-3">
            <label className="form-label">Email</label>
            <input className="form-control" value={profile.email} disabled />
          </div>
          <div className="mb-3">
            <label className="form-label">Full Name</label>
            <input className="form-control" value={form.fullName}
              onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
          </div>
          <div className="mb-3">
            <label className="form-label">Phone</label>
            <input className="form-control" value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          </div>
          <div className="mb-3">
            <label className="form-label">Preferences</label>
            <textarea className="form-control" rows={2} value={form.preferences}
              onChange={(e) => setForm({ ...form, preferences: e.target.value })} />
          </div>
          <button type="submit" className="btn btn-primary">Save Changes</button>
        </form>
      </div>

      <div className="ts-card bg-white p-4">
        <h5 className="mb-3">Change Password</h5>
        {pwMessage && <div className="alert alert-success">{pwMessage}</div>}
        {pwError && <div className="alert alert-danger">{pwError}</div>}
        <form onSubmit={changePassword}>
          <div className="mb-3">
            <label className="form-label">Current Password</label>
            <input type="password" className="form-control" required value={pwForm.currentPassword}
              onChange={(e) => setPwForm({ ...pwForm, currentPassword: e.target.value })} />
          </div>
          <div className="mb-3">
            <label className="form-label">New Password</label>
            <input type="password" className="form-control" required minLength={6} value={pwForm.newPassword}
              onChange={(e) => setPwForm({ ...pwForm, newPassword: e.target.value })} />
          </div>
          <button type="submit" className="btn btn-outline-primary">Change Password</button>
        </form>
      </div>
    </div>
  )
}
