import { Link } from 'react-router-dom'

const FEATURES = [
  { title: 'Plan Together', desc: 'Create a trip, invite your group, and organize everything from one shared workspace.' },
  { title: 'Assign Responsibilities', desc: 'Split up hotel booking, snacks, playlist, and more so nothing falls through the cracks.' },
  { title: 'Daily Itinerary', desc: 'A day-wise schedule everyone can see the moment they open the trip.' },
  { title: 'Split Expenses', desc: 'Track who paid for what and see a clear settlement summary at the end.' },
  { title: 'Vote on Suggestions', desc: 'Members propose hotels, restaurants, and activities; the group votes, the coordinator approves.' },
  { title: 'Shared Album', desc: 'Collect photos and videos from the whole group in one place, organized by day.' },
]

export default function LandingPage() {
  return (
    <div>
      <div className="container py-5">
        <div className="ts-hero p-5 mb-5 text-center">
          <h1 className="display-5 fw-bold">Plan your next group trip without the chaos</h1>
          <p className="lead mb-4">
            TripSync centralizes planning, coordination, and memories for group trips — no more
            scattered chats, spreadsheets, and lost information.
          </p>
          <div className="d-flex gap-2 justify-content-center">
            <Link to="/register" className="btn btn-light btn-lg">Get Started Free</Link>
            <Link to="/login" className="btn btn-outline-light btn-lg">Log In</Link>
          </div>
        </div>

        <h2 className="text-center mb-4" id="features">Everything your group needs</h2>
        <div className="row g-4 mb-5">
          {FEATURES.map((f) => (
            <div className="col-md-4" key={f.title}>
              <div className="ts-card p-4 h-100 bg-white">
                <h5 className="fw-bold">{f.title}</h5>
                <p className="text-muted mb-0">{f.desc}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="row g-4 mb-5" id="about">
          <div className="col-md-6">
            <h3>About TripSync</h3>
            <p className="text-muted">
              TripSync is not a booking website — it won't sell you flights or hotels. Instead, it's
              a collaborative workspace where your group organizes a trip before, during, and after
              travel: responsibilities, itinerary, budget, suggestions, checklist, album, and
              documents, all in one place.
            </p>
          </div>
          <div className="col-md-6" id="contact">
            <h3>Contact</h3>
            <p className="text-muted">
              Questions or feedback about this project? Reach out at
              {' '}<a href="mailto:support@tripsync.app">support@tripsync.app</a>.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
