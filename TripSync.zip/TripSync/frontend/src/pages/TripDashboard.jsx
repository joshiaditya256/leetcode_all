import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import api from '../api/axios.js'

import OverviewTab from '../components/trip/OverviewTab.jsx'
import MembersTab from '../components/trip/MembersTab.jsx'
import ResponsibilitiesTab from '../components/trip/ResponsibilitiesTab.jsx'
import ItineraryTab from '../components/trip/ItineraryTab.jsx'
import ExpensesTab from '../components/trip/ExpensesTab.jsx'
import SuggestionsTab from '../components/trip/SuggestionsTab.jsx'
import ChecklistTab from '../components/trip/ChecklistTab.jsx'
import AlbumTab from '../components/trip/AlbumTab.jsx'
import DocumentsTab from '../components/trip/DocumentsTab.jsx'

const TABS = [
  { key: 'overview', label: 'Overview' },
  { key: 'members', label: 'Members' },
  { key: 'responsibilities', label: 'Responsibilities' },
  { key: 'itinerary', label: 'Itinerary' },
  { key: 'expenses', label: 'Expenses' },
  { key: 'suggestions', label: 'Suggestions' },
  { key: 'checklist', label: 'Checklist' },
  { key: 'album', label: 'Album' },
  { key: 'documents', label: 'Documents' },
]

export default function TripDashboard() {
  const { tripId } = useParams()
  const id = Number(tripId)
  const [tab, setTab] = useState('overview')
  const [trip, setTrip] = useState(null)
  const [error, setError] = useState('')

  const loadTrip = () => {
    api.get(`/trips/${id}`)
      .then((res) => setTrip(res.data))
      .catch(() => setError('You do not have access to this trip, or it does not exist.'))
  }

  useEffect(loadTrip, [id])

  if (error) return <div className="container py-5"><div className="alert alert-danger">{error}</div></div>
  if (!trip) return <div className="container py-5 text-center">Loading…</div>

  const isCoordinator = trip.myRole === 'COORDINATOR'

  return (
    <div className="container py-4">
      <div className="d-flex justify-content-between align-items-start flex-wrap mb-3">
        <div>
          <h2 className="mb-0">{trip.name}</h2>
          <p className="text-muted mb-0">{trip.destination} · {trip.startDate} → {trip.endDate}</p>
        </div>
        <span className="badge bg-primary badge-status fs-6">{trip.status.toLowerCase()}</span>
      </div>

      <ul className="nav nav-tabs mb-3 flex-nowrap overflow-auto">
        {TABS.map((t) => (
          <li className="nav-item" key={t.key}>
            <button className={`nav-link text-nowrap ${tab === t.key ? 'active' : ''}`} onClick={() => setTab(t.key)}>
              {t.label}
            </button>
          </li>
        ))}
      </ul>

      <div>
        {tab === 'overview' && <OverviewTab tripId={id} onTripChanged={loadTrip} isCoordinator={isCoordinator} trip={trip} />}
        {tab === 'members' && <MembersTab tripId={id} isCoordinator={isCoordinator} />}
        {tab === 'responsibilities' && <ResponsibilitiesTab tripId={id} isCoordinator={isCoordinator} />}
        {tab === 'itinerary' && <ItineraryTab tripId={id} isCoordinator={isCoordinator} />}
        {tab === 'expenses' && <ExpensesTab tripId={id} />}
        {tab === 'suggestions' && <SuggestionsTab tripId={id} isCoordinator={isCoordinator} />}
        {tab === 'checklist' && <ChecklistTab tripId={id} />}
        {tab === 'album' && <AlbumTab tripId={id} />}
        {tab === 'documents' && <DocumentsTab tripId={id} />}
      </div>
    </div>
  )
}
