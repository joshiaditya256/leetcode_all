import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import api from '../api/axios.js'
import { useAuth } from '../context/AuthContext.jsx'

export default function UserDashboard() {
  const { user } = useAuth()
  const [data, setData] = useState(null)
  const [error, setError] = useState('')
  const [busyTripId, setBusyTripId] = useState(null)

  const load = () => {
    api.get('/dashboard')
      .then((res) => setData(res.data))
      .catch(() => setError('Could not load dashboard'))
  }

  useEffect(load, [])

  const respond = async (tripId, accept) => {
    setBusyTripId(tripId)
    try {
      await api.post(`/trips/${tripId}/members/respond`, null, { params: { accept } })
      load()
    } finally {
      setBusyTripId(null)
    }
  }

  if (error) return <div className="container py-5"><div className="alert alert-danger">{error}</div></div>
  if (!data) return <div className="container py-5 text-center">Loading…</div>

  return (
    <div className="container py-4">
      <h2 className="mb-4">Welcome back, {user?.fullName?.split(' ')[0]} 👋</h2>

      {data.pendingInvitations.length > 0 && (
        <div className="ts-card bg-white p-3 mb-4">
          <h5>Pending Invitations</h5>
          {data.pendingInvitations.map((inv) => (
            <div key={inv.id} className="d-flex justify-content-between align-items-center border-top py-2">
              <span>You've been invited to <strong>{inv.tripName}</strong></span>
              <div>
                <button className="btn btn-sm btn-success me-2" disabled={busyTripId === inv.tripId}
                  onClick={() => respond(inv.tripId, true)}>Accept</button>
                <button className="btn btn-sm btn-outline-danger" disabled={busyTripId === inv.tripId}
                  onClick={() => respond(inv.tripId, false)}>Decline</button>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="row g-4">
        <div className="col-lg-8">
          <div className="d-flex justify-content-between align-items-center mb-3">
            <h5 className="mb-0">My Trips</h5>
            <Link to="/trips/new" className="btn btn-primary btn-sm">+ Create Trip</Link>
          </div>
          {data.allTrips.length === 0 ? (
            <div className="ts-card bg-white p-4 text-center text-muted">
              No trips yet. Create your first trip to get started!
            </div>
          ) : (
            <div className="row g-3">
              {data.allTrips.map((trip) => (
                <div className="col-md-6" key={trip.id}>
                  <Link to={`/trips/${trip.id}`} className="text-decoration-none text-dark">
                    <div className="ts-card bg-white p-3 h-100">
                      <div className="d-flex justify-content-between">
                        <h6 className="fw-bold mb-1">{trip.name}</h6>
                        <span className="badge bg-primary badge-status">{trip.status.toLowerCase()}</span>
                      </div>
                      <p className="text-muted small mb-1">{trip.destination}</p>
                      <p className="small mb-0">{trip.startDate} → {trip.endDate}</p>
                      <p className="small text-muted mb-0">{trip.memberCount} member(s) · {trip.myRole}</p>
                    </div>
                  </Link>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="col-lg-4">
          <h5 className="mb-3">Recent Notifications</h5>
          <div className="ts-card bg-white p-3">
            {data.recentNotifications.length === 0 ? (
              <p className="text-muted mb-0">No notifications yet.</p>
            ) : (
              data.recentNotifications.map((n) => (
                <div key={n.id} className={`border-bottom py-2 ${n.isRead ? '' : 'fw-bold'}`}>
                  <p className="mb-0 small">{n.message}</p>
                  <span className="text-muted" style={{ fontSize: '0.75rem' }}>
                    {new Date(n.createdAt).toLocaleString()}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
