import { createContext, useContext, useEffect, useState } from 'react'
import api from '../api/axios'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem('tripsync_user')
    return stored ? JSON.parse(stored) : null
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const token = localStorage.getItem('tripsync_token')
    if (token) {
      api.get('/auth/me')
        .then((res) => {
          setUser(res.data)
          localStorage.setItem('tripsync_user', JSON.stringify(res.data))
        })
        .catch(() => {
          localStorage.removeItem('tripsync_token')
          localStorage.removeItem('tripsync_user')
          setUser(null)
        })
        .finally(() => setLoading(false))
    } else {
      setLoading(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const login = async (email, password) => {
    const res = await api.post('/auth/login', { email, password })
    localStorage.setItem('tripsync_token', res.data.token)
    const profile = {
      id: res.data.userId,
      fullName: res.data.fullName,
      email: res.data.email,
      role: res.data.role,
    }
    localStorage.setItem('tripsync_user', JSON.stringify(profile))
    setUser(profile)
    return profile
  }

  const register = async (payload) => {
    const res = await api.post('/auth/register', payload)
    localStorage.setItem('tripsync_token', res.data.token)
    const profile = {
      id: res.data.userId,
      fullName: res.data.fullName,
      email: res.data.email,
      role: res.data.role,
    }
    localStorage.setItem('tripsync_user', JSON.stringify(profile))
    setUser(profile)
    return profile
  }

  const logout = () => {
    localStorage.removeItem('tripsync_token')
    localStorage.removeItem('tripsync_user')
    setUser(null)
  }

  const refreshProfile = async () => {
    const res = await api.get('/auth/me')
    setUser((prev) => ({ ...prev, ...res.data }))
    localStorage.setItem('tripsync_user', JSON.stringify(res.data))
    return res.data
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, refreshProfile }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
