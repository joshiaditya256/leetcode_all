import { useEffect, useState } from 'react'
import api from '../../api/axios.js'
import { useAuth } from '../../context/AuthContext.jsx'

const STATUSES = ['PENDING', 'IN_PROGRESS', 'COMPLETED']
const STATUS_LABELS = { PENDING: 'Pending', IN_PROGRESS: 'In Progress', COMPLETED: 'Completed' }

export default function ResponsibilitiesTab({ tripId, isCoordinator }) {
  const { user } = useAuth()
  const [items, setItems] = useState([])
  const [members, setMembers] = useState([])
  const [form, setForm] = useState({ title: '', description: '', assignedToUserId: '', dueDate: '', priority: 'MEDIUM' })
  const [showForm, setShowForm] = useState(false)

  const load = () => api.get(`/trips/${tripId}/responsibilities`).then((res) => setItems(res.data))

  useEffect(() => {
    load()
    api.get(`/trips/${tripId}/members`).then((res) => setMembers(res.data.filter((m) => m.status === 'ACCEPTED')))
  }, [tripId])

  const create = async (e) => {
    e.preventDefault()
    await api.post(`/trips/${tripId}/responsibilities`, {
      ...form,
      assignedToUserId: form.assignedToUserId || null,
      dueDate: form.dueDate || null,
    })
    setForm({ title: '', description: '', assignedToUserId: '', dueDate: '', priority: 'MEDIUM' })
    setShowForm(false)
    load()
  }

  const updateStatus = async (item, status) => {
    await api.put(`/trips/${tripId}/responsibilities/${item.id}`, { status })
    load()
  }

  const remove = async (id) => {
    if (!confirm('Delete this responsibility?')) return
    await api.delete(`/trips/${tripId}/responsibilities/${id}`)
    load()
  }

  return (
    <div>
      {isCoordinator && (
        <div className="mb-3">
          <button className="btn btn-primary btn-sm" onClick={() => setShowForm((s) => !s)}>
            {showForm ? 'Cancel' : '+ Assign Responsibility'}
          </button>
        </div>
      )}

      {showForm && (
        <form onSubmit={create} className="ts-card bg-white p-3 mb-4">
          <div className="row g-2">
            <div className="col-md-6">
              <input className="form-control" placeholder="Title (e.g. Hotel Booking)" required
                value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
            </div>
            <div className="col-md-6">
              <select className="form-select" value={form.assignedToUserId}
                onChange={(e) => setForm({ ...form, assignedToUserId: e.target.value })}>
                <option value="">Unassigned</option>
                {members.map((m) => <option key={m.userId} value={m.userId}>{m.fullName}</option>)}
              </select>
            </div>
            <div className="col-md-4">
              <input type="date" className="form-control" value={form.dueDate}
                onChange={(e) => setForm({ ...form, dueDate: e.target.value })} />
            </div>
            <div className="col-md-4">
              <select className="form-select" value={form.priority}
                onChange={(e) => setForm({ ...form, priority: e.target.value })}>
                <option value="LOW">Low</option>
                <option value="MEDIUM">Medium</option>
                <option value="HIGH">High</option>
              </select>
            </div>
            <div className="col-md-4">
              <button className="btn btn-primary w-100">Create</button>
            </div>
            <div className="col-12">
              <textarea className="form-control" rows={2} placeholder="Description (optional)"
                value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </div>
          </div>
        </form>
      )}

      <div className="row g-3">
        {STATUSES.map((status) => (
          <div className="col-md-4" key={status}>
            <h6 className="text-muted">{STATUS_LABELS[status]}</h6>
            <div className="d-flex flex-column gap-2">
              {items.filter((i) => i.status === status).map((item) => (
                <div className="ts-card bg-white p-3" key={item.id}>
                  <div className="d-flex justify-content-between">
                    <strong>{item.title}</strong>
                    <span className={`badge ${item.priority === 'HIGH' ? 'bg-danger' : item.priority === 'LOW' ? 'bg-secondary' : 'bg-warning text-dark'}`}>
                      {item.priority}
                    </span>
                  </div>
                  {item.description && <p className="small text-muted mb-1">{item.description}</p>}
                  <p className="small mb-2">
                    {item.assignedToName || 'Unassigned'}{item.dueDate ? ` · due ${item.dueDate}` : ''}
                  </p>
                  <div className="d-flex gap-2 flex-wrap">
                    {STATUSES.filter((s) => s !== status).map((s) => (
                      (isCoordinator || item.assignedToUserId === user?.id) && (
                        <button key={s} className="btn btn-sm btn-outline-secondary"
                          onClick={() => updateStatus(item, s)}>
                          Move to {STATUS_LABELS[s]}
                        </button>
                      )
                    ))}
                    {isCoordinator && (
                      <button className="btn btn-sm btn-outline-danger" onClick={() => remove(item.id)}>Delete</button>
                    )}
                  </div>
                </div>
              ))}
              {items.filter((i) => i.status === status).length === 0 && (
                <p className="text-muted small">Nothing here.</p>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
