import { useEffect, useRef, useState } from 'react'
import api, { fileBaseUrl } from '../../api/axios.js'

const DOC_TYPES = [
  'HOTEL_CONFIRMATION', 'BUS_TICKET', 'TRAIN_TICKET', 'FLIGHT_TICKET',
  'IDENTITY_DOCUMENT', 'EMERGENCY_CONTACT', 'OTHER',
]

export default function DocumentsTab({ tripId }) {
  const [docs, setDocs] = useState([])
  const [docType, setDocType] = useState('HOTEL_CONFIRMATION')
  const [uploading, setUploading] = useState(false)
  const fileInputRef = useRef(null)

  const load = () => api.get(`/trips/${tripId}/documents`).then((res) => setDocs(res.data))

  useEffect(load, [tripId])

  const handleUpload = async (e) => {
    const file = e.target.files[0]
    if (!file) return
    setUploading(true)
    try {
      const formData = new FormData()
      formData.append('file', file)
      formData.append('documentType', docType)
      await api.post(`/trips/${tripId}/documents`, formData, { headers: { 'Content-Type': 'multipart/form-data' } })
      if (fileInputRef.current) fileInputRef.current.value = ''
      load()
    } finally {
      setUploading(false)
    }
  }

  const remove = async (id) => {
    if (!confirm('Delete this document?')) return
    await api.delete(`/trips/${tripId}/documents/${id}`)
    load()
  }

  return (
    <div>
      <div className="ts-card bg-white p-3 mb-4">
        <h6>Upload Document</h6>
        <div className="row g-2 align-items-end">
          <div className="col-md-4">
            <label className="form-label small">Type</label>
            <select className="form-select" value={docType} onChange={(e) => setDocType(e.target.value)}>
              {DOC_TYPES.map((t) => <option key={t} value={t}>{t.replace(/_/g, ' ')}</option>)}
            </select>
          </div>
          <div className="col-md-8">
            <input ref={fileInputRef} type="file" className="form-control" onChange={handleUpload} disabled={uploading} />
          </div>
        </div>
      </div>

      <div className="ts-card bg-white p-3">
        {docs.length === 0 ? <p className="text-muted mb-0">No documents uploaded yet.</p> : (
          <table className="table align-middle mb-0">
            <thead><tr><th>Type</th><th>File</th><th>Uploaded By</th><th></th></tr></thead>
            <tbody>
              {docs.map((d) => (
                <tr key={d.id}>
                  <td>{d.documentType.replace(/_/g, ' ')}</td>
                  <td><a href={`${fileBaseUrl}${d.filePath}`} target="_blank" rel="noreferrer">{d.fileName}</a></td>
                  <td>{d.uploadedByName}</td>
                  <td><button className="btn btn-sm btn-outline-danger" onClick={() => remove(d.id)}>Delete</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
