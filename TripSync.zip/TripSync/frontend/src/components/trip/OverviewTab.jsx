import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import api from '../../api/axios.js'

export default function OverviewTab({ tripId, isCoordinator, trip }) {
  const navigate = useNavigate()
  const [dash, setDash] = useState(null)

  useEffect(() => {
    api.get(`/dashboard/trips/${tripId}`).then((res) => setDash(res.data))
  }, [tripId])

  const closeTrip = async () => {
    if (!confirm('Mark this trip as completed?')) return
    await api.post(`/trips/${tripId}/close`)
    window.location.reload()
  }

  const archiveTrip = async () => {
    if (!confirm('Archive this trip?')) return
    await api.post(`/trips/${tripId}/archive`)
    window.location.reload()
  }

  const deleteTrip = async () => {
    if (!confirm('Delete this trip permanently? This cannot be undone.')) return
    await api.delete(`/trips/${tripId}`)
    navigate('/dashboard')
  }

  const leaveTrip = async () => {
    if (!confirm('Leave this trip?')) return
    await api.post(`/trips/${tripId}/leave`)
    navigate('/dashboard')
  }

  return (
    <div className="row g-4">
      <div className="col-md-8">
        <div className="ts-card bg-white p-4 mb-4">
          <h5>About this trip</h5>
          <p className="text-muted mb-2">{trip.description || 'No description yet.'}</p>
          {trip.budget != null && <p className="mb-0">Budget: <strong>{trip.budget}</strong></p>}
        </div>

        <div className="ts-card bg-white p-4 mb-4">
          <h5>Today's Plan</h5>
          {!dash ? <p className="text-muted">Loading…</p> : dash.todaysPlan.length === 0 ? (
            <p className="text-muted mb-0">Nothing scheduled for today.</p>
          ) : (
            <ul className="list-group list-group-flush">
              {dash.todaysPlan.map((item) => (
                <li key={item.id} className="list-group-item px-0">
                  <strong>{item.time || ''}</strong> {item.activity} {item.place && `@ ${item.place}`}
                </li>
              ))}
            </ul>
          )}
        </div>

        {dash && (
          <div className="ts-card bg-white p-4">
            <h5>Member Progress</h5>
            {dash.memberProgress.map((m) => (
              <div key={m.userId} className="mb-2">
                <div className="d-flex justify-content-between small">
                  <span>{m.userName}</span>
                  <span>{m.completedTasks}/{m.totalTasks}</span>
                </div>
                <div className="progress" style={{ height: 6 }}>
                  <div className="progress-bar" style={{
                    width: `${m.totalTasks ? (m.completedTasks / m.totalTasks) * 100 : 0}%`,
                  }} />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="col-md-4">
        <div className="ts-card bg-white p-4 mb-4 text-center">
          <div className="fs-2 fw-bold">{trip.daysUntilStart >= 0 ? trip.daysUntilStart : 0}</div>
          <div className="text-muted">days until the trip starts</div>
        </div>

        {dash && (
          <div className="ts-card bg-white p-4 mb-4">
            <h6>Expense Summary</h6>
            <p className="mb-1 small">Spent: <strong>{dash.expenseSummary.totalSpent}</strong></p>
            {trip.budget != null && (
              <p className="mb-0 small">Remaining: <strong>{dash.expenseSummary.remainingBudget}</strong></p>
            )}
          </div>
        )}

        <div className="ts-card bg-white p-4">
          <h6>Trip Actions</h6>
          {isCoordinator ? (
            <div className="d-grid gap-2">
              <button className="btn btn-outline-primary btn-sm" onClick={closeTrip}>Mark as Completed</button>
              <button className="btn btn-outline-secondary btn-sm" onClick={archiveTrip}>Archive Trip</button>
              <button className="btn btn-outline-danger btn-sm" onClick={deleteTrip}>Delete Trip</button>
            </div>
          ) : (
            <button className="btn btn-outline-danger btn-sm w-100" onClick={leaveTrip}>Leave Trip</button>
          )}
        </div>
      </div>
    </div>
  )
}
