import { useEffect, useState } from 'react'
import api from '../../api/axios.js'

export default function MembersTab({ tripId, isCoordinator }) {
  const [members, setMembers] = useState([])
  const [email, setEmail] = useState('')
  const [error, setError] = useState('')
  const [availability, setAvailability] = useState('')

  const load = () => api.get(`/trips/${tripId}/members`).then((res) => setMembers(res.data))

  useEffect(load, [tripId])

  const invite = async (e) => {
    e.preventDefault()
    setError('')
    try {
      await api.post(`/trips/${tripId}/members/invite`, { email })
      setEmail('')
      load()
    } catch (err) {
      setError(err.response?.data?.message || 'Could not invite member')
    }
  }

  const remove = async (userId) => {
    if (!confirm('Remove this member from the trip?')) return
    await api.delete(`/trips/${tripId}/members/${userId}`)
    load()
  }

  const saveAvailability = async () => {
    await api.put(`/trips/${tripId}/members/availability`, { availability })
    load()
  }

  return (
    <div className="row g-4">
      <div className="col-md-8">
        <div className="ts-card bg-white p-3">
          <table className="table align-middle mb-0">
            <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Availability</th>{isCoordinator && <th></th>}</tr></thead>
            <tbody>
              {members.map((m) => (
                <tr key={m.id}>
                  <td>{m.fullName}</td>
                  <td>{m.email}</td>
                  <td>{m.role}</td>
                  <td><span className="badge bg-secondary badge-status">{m.status.toLowerCase()}</span></td>
                  <td className="small text-muted">{m.availability || '—'}</td>
                  {isCoordinator && (
                    <td>
                      {m.role !== 'COORDINATOR' && (
                        <button className="btn btn-sm btn-outline-danger" onClick={() => remove(m.userId)}>Remove</button>
                      )}
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="col-md-4">
        {isCoordinator && (
          <div className="ts-card bg-white p-3 mb-3">
            <h6>Invite Member</h6>
            {error && <div className="alert alert-danger py-2">{error}</div>}
            <form onSubmit={invite} className="d-flex gap-2">
              <input type="email" className="form-control" placeholder="email@example.com" required
                value={email} onChange={(e) => setEmail(e.target.value)} />
              <button className="btn btn-primary">Invite</button>
            </form>
            <div className="form-text">They must already have a TripSync account.</div>
          </div>
        )}

        <div className="ts-card bg-white p-3">
          <h6>My Availability</h6>
          <textarea className="form-control mb-2" rows={2} placeholder="e.g. Free after 6pm, unavailable Day 2"
            value={availability} onChange={(e) => setAvailability(e.target.value)} />
          <button className="btn btn-outline-primary btn-sm" onClick={saveAvailability}>Save</button>
        </div>
      </div>
    </div>
  )
}
