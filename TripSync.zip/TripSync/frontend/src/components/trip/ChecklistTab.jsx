import { useEffect, useState } from 'react'
import api from '../../api/axios.js'

export default function ChecklistTab({ tripId }) {
  const [items, setItems] = useState([])
  const [members, setMembers] = useState([])
  const [form, setForm] = useState({ itemName: '', assignedToUserId: '', quantity: 1 })

  const load = () => api.get(`/trips/${tripId}/checklist`).then((res) => setItems(res.data))

  useEffect(() => {
    load()
    api.get(`/trips/${tripId}/members`).then((res) => setMembers(res.data.filter((m) => m.status === 'ACCEPTED')))
  }, [tripId])

  const create = async (e) => {
    e.preventDefault()
    await api.post(`/trips/${tripId}/checklist`, {
      ...form,
      assignedToUserId: form.assignedToUserId || null,
      quantity: Number(form.quantity) || 1,
    })
    setForm({ itemName: '', assignedToUserId: '', quantity: 1 })
    load()
  }

  const togglePacked = async (item) => {
    await api.put(`/trips/${tripId}/checklist/${item.id}`, {
      status: item.status === 'PACKED' ? 'PENDING' : 'PACKED',
    })
    load()
  }

  const remove = async (id) => {
    await api.delete(`/trips/${tripId}/checklist/${id}`)
    load()
  }

  return (
    <div className="row g-4">
      <div className="col-md-8">
        <div className="ts-card bg-white p-3">
          {items.length === 0 ? <p className="text-muted mb-0">No checklist items yet.</p> : (
            <table className="table align-middle mb-0">
              <thead><tr><th></th><th>Item</th><th>Assigned</th><th>Qty</th><th></th></tr></thead>
              <tbody>
                {items.map((item) => (
                  <tr key={item.id} className={item.status === 'PACKED' ? 'text-decoration-line-through text-muted' : ''}>
                    <td>
                      <input type="checkbox" className="form-check-input"
                        checked={item.status === 'PACKED'} onChange={() => togglePacked(item)} />
                    </td>
                    <td>{item.itemName}</td>
                    <td>{item.assignedToName || '—'}</td>
                    <td>{item.quantity}</td>
                    <td><button className="btn btn-sm btn-outline-danger" onClick={() => remove(item.id)}>Delete</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
      <div className="col-md-4">
        <div className="ts-card bg-white p-3">
          <h6>Add Item</h6>
          <form onSubmit={create}>
            <input className="form-control mb-2" placeholder="Item name (e.g. Charger)" required
              value={form.itemName} onChange={(e) => setForm({ ...form, itemName: e.target.value })} />
            <select className="form-select mb-2" value={form.assignedToUserId}
              onChange={(e) => setForm({ ...form, assignedToUserId: e.target.value })}>
              <option value="">Unassigned</option>
              {members.map((m) => <option key={m.userId} value={m.userId}>{m.fullName}</option>)}
            </select>
            <input type="number" min="1" className="form-control mb-2" value={form.quantity}
              onChange={(e) => setForm({ ...form, quantity: e.target.value })} />
            <button className="btn btn-primary w-100">Add</button>
          </form>
        </div>
      </div>
    </div>
  )
}
