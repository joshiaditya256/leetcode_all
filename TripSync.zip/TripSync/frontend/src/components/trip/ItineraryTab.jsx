import { useEffect, useState } from 'react'
import api from '../../api/axios.js'

export default function ItineraryTab({ tripId, isCoordinator }) {
  const [items, setItems] = useState([])
  const [members, setMembers] = useState([])
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ dayNumber: 1, date: '', time: '', activity: '', place: '', notes: '', responsiblePersonId: '' })

  const load = () => api.get(`/trips/${tripId}/itinerary`).then((res) => setItems(res.data))

  useEffect(() => {
    load()
    api.get(`/trips/${tripId}/members`).then((res) => setMembers(res.data.filter((m) => m.status === 'ACCEPTED')))
  }, [tripId])

  const create = async (e) => {
    e.preventDefault()
    await api.post(`/trips/${tripId}/itinerary`, {
      ...form,
      dayNumber: Number(form.dayNumber),
      responsiblePersonId: form.responsiblePersonId || null,
    })
    setForm({ dayNumber: 1, date: '', time: '', activity: '', place: '', notes: '', responsiblePersonId: '' })
    setShowForm(false)
    load()
  }

  const remove = async (id) => {
    if (!confirm('Delete this itinerary item?')) return
    await api.delete(`/trips/${tripId}/itinerary/${id}`)
    load()
  }

  const grouped = items.reduce((acc, item) => {
    (acc[item.dayNumber] = acc[item.dayNumber] || []).push(item)
    return acc
  }, {})

  return (
    <div>
      {isCoordinator && (
        <div className="mb-3">
          <button className="btn btn-primary btn-sm" onClick={() => setShowForm((s) => !s)}>
            {showForm ? 'Cancel' : '+ Add Itinerary Item'}
          </button>
        </div>
      )}

      {showForm && (
        <form onSubmit={create} className="ts-card bg-white p-3 mb-4">
          <div className="row g-2">
            <div className="col-md-2">
              <label className="form-label small">Day #</label>
              <input type="number" min="1" className="form-control" required
                value={form.dayNumber} onChange={(e) => setForm({ ...form, dayNumber: e.target.value })} />
            </div>
            <div className="col-md-3">
              <label className="form-label small">Date</label>
              <input type="date" className="form-control" required
                value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
            </div>
            <div className="col-md-2">
              <label className="form-label small">Time</label>
              <input type="time" className="form-control"
                value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} />
            </div>
            <div className="col-md-5">
              <label className="form-label small">Activity</label>
              <input className="form-control" required
                value={form.activity} onChange={(e) => setForm({ ...form, activity: e.target.value })} />
            </div>
            <div className="col-md-4">
              <label className="form-label small">Place</label>
              <input className="form-control"
                value={form.place} onChange={(e) => setForm({ ...form, place: e.target.value })} />
            </div>
            <div className="col-md-4">
              <label className="form-label small">Responsible Person</label>
              <select className="form-select" value={form.responsiblePersonId}
                onChange={(e) => setForm({ ...form, responsiblePersonId: e.target.value })}>
                <option value="">Nobody</option>
                {members.map((m) => <option key={m.userId} value={m.userId}>{m.fullName}</option>)}
              </select>
            </div>
            <div className="col-md-4 d-flex align-items-end">
              <button className="btn btn-primary w-100">Add</button>
            </div>
            <div className="col-12">
              <textarea className="form-control" rows={2} placeholder="Notes (optional)"
                value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
            </div>
          </div>
        </form>
      )}

      {Object.keys(grouped).length === 0 ? (
        <p className="text-muted">No itinerary yet.</p>
      ) : (
        Object.keys(grouped).sort((a, b) => a - b).map((day) => (
          <div key={day} className="mb-4">
            <h5>Day {day}</h5>
            <div className="ts-card bg-white p-3">
              {grouped[day].map((item) => (
                <div key={item.id} className="d-flex justify-content-between align-items-start border-bottom py-2">
                  <div>
                    <strong>{item.time ? item.time.slice(0, 5) : ''} {item.activity}</strong>
                    {item.place && <span className="text-muted"> @ {item.place}</span>}
                    {item.notes && <p className="small text-muted mb-0">{item.notes}</p>}
                    {item.responsiblePersonName && <p className="small mb-0">Responsible: {item.responsiblePersonName}</p>}
                  </div>
                  {isCoordinator && (
                    <button className="btn btn-sm btn-outline-danger" onClick={() => remove(item.id)}>Delete</button>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))
      )}
    </div>
  )
}
