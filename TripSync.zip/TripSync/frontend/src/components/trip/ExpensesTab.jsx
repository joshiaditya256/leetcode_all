import { useEffect, useState } from 'react'
import api from '../../api/axios.js'

export default function ExpensesTab({ tripId }) {
  const [expenses, setExpenses] = useState([])
  const [summary, setSummary] = useState(null)
  const [members, setMembers] = useState([])
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ title: '', category: '', amount: '', notes: '', splitBetweenUserIds: [] })

  const load = () => {
    api.get(`/trips/${tripId}/expenses`).then((res) => setExpenses(res.data))
    api.get(`/trips/${tripId}/expenses/summary`).then((res) => setSummary(res.data))
  }

  useEffect(() => {
    load()
    api.get(`/trips/${tripId}/members`).then((res) => setMembers(res.data.filter((m) => m.status === 'ACCEPTED')))
  }, [tripId])

  const toggleSplit = (userId) => {
    setForm((f) => ({
      ...f,
      splitBetweenUserIds: f.splitBetweenUserIds.includes(userId)
        ? f.splitBetweenUserIds.filter((id) => id !== userId)
        : [...f.splitBetweenUserIds, userId],
    }))
  }

  const create = async (e) => {
    e.preventDefault()
    await api.post(`/trips/${tripId}/expenses`, {
      title: form.title,
      category: form.category,
      amount: Number(form.amount),
      notes: form.notes,
      splitBetweenUserIds: form.splitBetweenUserIds.length ? form.splitBetweenUserIds : null,
    })
    setForm({ title: '', category: '', amount: '', notes: '', splitBetweenUserIds: [] })
    setShowForm(false)
    load()
  }

  const remove = async (id) => {
    if (!confirm('Delete this expense?')) return
    await api.delete(`/trips/${tripId}/expenses/${id}`)
    load()
  }

  return (
    <div className="row g-4">
      <div className="col-md-8">
        <button className="btn btn-primary btn-sm mb-3" onClick={() => setShowForm((s) => !s)}>
          {showForm ? 'Cancel' : '+ Add Expense'}
        </button>

        {showForm && (
          <form onSubmit={create} className="ts-card bg-white p-3 mb-4">
            <div className="row g-2">
              <div className="col-md-6">
                <input className="form-control" placeholder="Title" required
                  value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
              </div>
              <div className="col-md-3">
                <input className="form-control" placeholder="Category" required
                  value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} />
              </div>
              <div className="col-md-3">
                <input type="number" min="0" step="0.01" className="form-control" placeholder="Amount" required
                  value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
              </div>
              <div className="col-12">
                <label className="form-label small">Split between (default: everyone)</label>
                <div className="d-flex flex-wrap gap-2">
                  {members.map((m) => (
                    <label key={m.userId} className="form-check-label border rounded px-2 py-1">
                      <input type="checkbox" className="form-check-input me-1"
                        checked={form.splitBetweenUserIds.includes(m.userId)}
                        onChange={() => toggleSplit(m.userId)} />
                      {m.fullName}
                    </label>
                  ))}
                </div>
              </div>
              <div className="col-12">
                <textarea className="form-control" rows={2} placeholder="Notes (optional)"
                  value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
              </div>
              <div className="col-12">
                <button className="btn btn-primary">Add Expense</button>
              </div>
            </div>
          </form>
        )}

        <div className="ts-card bg-white p-3">
          <h6>Expense History</h6>
          {expenses.length === 0 ? <p className="text-muted mb-0">No expenses yet.</p> : (
            <table className="table align-middle mb-0">
              <thead><tr><th>Title</th><th>Category</th><th>Amount</th><th>Paid By</th><th></th></tr></thead>
              <tbody>
                {expenses.map((e) => (
                  <tr key={e.id}>
                    <td>{e.title}</td>
                    <td>{e.category}</td>
                    <td>{e.amount}</td>
                    <td>{e.paidByName}</td>
                    <td><button className="btn btn-sm btn-outline-danger" onClick={() => remove(e.id)}>Delete</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      <div className="col-md-4">
        {summary && (
          <div className="ts-card bg-white p-3 mb-3">
            <h6>Budget</h6>
            <p className="mb-1 small">Total Spent: <strong>{summary.totalSpent}</strong></p>
            <p className="mb-1 small">Budget: <strong>{summary.budget}</strong></p>
            <p className="mb-0 small">Remaining: <strong>{summary.remainingBudget}</strong></p>
          </div>
        )}
        {summary && (
          <div className="ts-card bg-white p-3">
            <h6>Settlement Summary</h6>
            {summary.settlements.length === 0 ? (
              <p className="text-muted small mb-0">Everyone is settled up.</p>
            ) : (
              summary.settlements.map((s, idx) => (
                <p key={idx} className="small mb-1">
                  <strong>{s.fromUserName}</strong> owes <strong>{s.toUserName}</strong> {s.amount}
                </p>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  )
}
