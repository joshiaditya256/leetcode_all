import { useEffect, useState } from 'react'
import api from '../../api/axios.js'

const TYPES = ['HOTEL', 'RESTAURANT', 'TOURIST_SPOT', 'BUDGET', 'ROUTE', 'ACTIVITY']

export default function SuggestionsTab({ tripId, isCoordinator }) {
  const [suggestions, setSuggestions] = useState([])
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ type: 'HOTEL', title: '', description: '' })
  const [openComments, setOpenComments] = useState(null)
  const [comments, setComments] = useState([])
  const [commentText, setCommentText] = useState('')

  const load = () => api.get(`/trips/${tripId}/suggestions`).then((res) => setSuggestions(res.data))

  useEffect(load, [tripId])

  const create = async (e) => {
    e.preventDefault()
    await api.post(`/trips/${tripId}/suggestions`, form)
    setForm({ type: 'HOTEL', title: '', description: '' })
    setShowForm(false)
    load()
  }

  const vote = async (id) => {
    await api.post(`/trips/${tripId}/suggestions/${id}/vote`)
    load()
  }

  const approve = async (id) => {
    await api.post(`/trips/${tripId}/suggestions/${id}/approve`)
    load()
  }

  const reject = async (id) => {
    await api.post(`/trips/${tripId}/suggestions/${id}/reject`)
    load()
  }

  const toggleComments = async (id) => {
    if (openComments === id) {
      setOpenComments(null)
      return
    }
    setOpenComments(id)
    const res = await api.get(`/trips/${tripId}/suggestions/${id}/comments`)
    setComments(res.data)
  }

  const addComment = async (id) => {
    if (!commentText.trim()) return
    await api.post(`/trips/${tripId}/suggestions/${id}/comments`, { comment: commentText })
    setCommentText('')
    const res = await api.get(`/trips/${tripId}/suggestions/${id}/comments`)
    setComments(res.data)
  }

  return (
    <div>
      <button className="btn btn-primary btn-sm mb-3" onClick={() => setShowForm((s) => !s)}>
        {showForm ? 'Cancel' : '+ New Suggestion'}
      </button>

      {showForm && (
        <form onSubmit={create} className="ts-card bg-white p-3 mb-4">
          <div className="row g-2">
            <div className="col-md-3">
              <select className="form-select" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
                {TYPES.map((t) => <option key={t} value={t}>{t.replace('_', ' ')}</option>)}
              </select>
            </div>
            <div className="col-md-6">
              <input className="form-control" placeholder="Title" required
                value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
            </div>
            <div className="col-md-3">
              <button className="btn btn-primary w-100">Submit</button>
            </div>
            <div className="col-12">
              <textarea className="form-control" rows={2} placeholder="Description (optional)"
                value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </div>
          </div>
        </form>
      )}

      <div className="d-flex flex-column gap-3">
        {suggestions.map((s) => (
          <div key={s.id} className="ts-card bg-white p-3">
            <div className="d-flex justify-content-between align-items-start">
              <div>
                <span className="badge bg-info text-dark me-2">{s.type.replace('_', ' ')}</span>
                <strong>{s.title}</strong>
                <span className={`badge ms-2 ${s.status === 'APPROVED' ? 'bg-success' : s.status === 'REJECTED' ? 'bg-danger' : 'bg-secondary'}`}>
                  {s.status}
                </span>
              </div>
            </div>
            {s.description && <p className="small text-muted mt-2 mb-1">{s.description}</p>}
            <p className="small text-muted mb-2">Suggested by {s.suggestedByName}</p>
            <div className="d-flex gap-2 flex-wrap">
              <button className={`btn btn-sm ${s.votedByMe ? 'btn-primary' : 'btn-outline-primary'}`} onClick={() => vote(s.id)}>
                👍 {s.voteCount}
              </button>
              <button className="btn btn-sm btn-outline-secondary" onClick={() => toggleComments(s.id)}>Comments</button>
              {isCoordinator && s.status === 'PENDING' && (
                <>
                  <button className="btn btn-sm btn-outline-success" onClick={() => approve(s.id)}>Approve</button>
                  <button className="btn btn-sm btn-outline-danger" onClick={() => reject(s.id)}>Reject</button>
                </>
              )}
            </div>

            {openComments === s.id && (
              <div className="mt-3 border-top pt-3">
                {comments.map((c) => (
                  <p key={c.id} className="small mb-1"><strong>{c.userName}:</strong> {c.comment}</p>
                ))}
                <div className="d-flex gap-2 mt-2">
                  <input className="form-control form-control-sm" placeholder="Add a comment…"
                    value={commentText} onChange={(e) => setCommentText(e.target.value)} />
                  <button className="btn btn-sm btn-primary" onClick={() => addComment(s.id)}>Post</button>
                </div>
              </div>
            )}
          </div>
        ))}
        {suggestions.length === 0 && <p className="text-muted">No suggestions yet — be the first!</p>}
      </div>
    </div>
  )
}
