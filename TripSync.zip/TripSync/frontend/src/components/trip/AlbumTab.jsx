import { useEffect, useRef, useState } from 'react'
import api, { fileBaseUrl } from '../../api/axios.js'

export default function AlbumTab({ tripId }) {
  const [media, setMedia] = useState([])
  const [caption, setCaption] = useState('')
  const [dayNumber, setDayNumber] = useState('')
  const [uploading, setUploading] = useState(false)
  const [openComments, setOpenComments] = useState(null)
  const [comments, setComments] = useState([])
  const [commentText, setCommentText] = useState('')
  const fileInputRef = useRef(null)

  const load = () => api.get(`/trips/${tripId}/album`).then((res) => setMedia(res.data))

  useEffect(load, [tripId])

  const handleUpload = async (e) => {
    const file = e.target.files[0]
    if (!file) return
    setUploading(true)
    try {
      const formData = new FormData()
      formData.append('file', file)
      if (caption) formData.append('caption', caption)
      if (dayNumber) formData.append('dayNumber', dayNumber)
      await api.post(`/trips/${tripId}/album`, formData, { headers: { 'Content-Type': 'multipart/form-data' } })
      setCaption('')
      setDayNumber('')
      if (fileInputRef.current) fileInputRef.current.value = ''
      load()
    } finally {
      setUploading(false)
    }
  }

  const toggleLike = async (id) => {
    await api.post(`/trips/${tripId}/album/${id}/like`)
    load()
  }

  const remove = async (id) => {
    if (!confirm('Delete this memory?')) return
    await api.delete(`/trips/${tripId}/album/${id}`)
    load()
  }

  const toggleComments = async (id) => {
    if (openComments === id) {
      setOpenComments(null)
      return
    }
    setOpenComments(id)
    const res = await api.get(`/trips/${tripId}/album/${id}/comments`)
    setComments(res.data)
  }

  const addComment = async (id) => {
    if (!commentText.trim()) return
    await api.post(`/trips/${tripId}/album/${id}/comments`, { comment: commentText })
    setCommentText('')
    const res = await api.get(`/trips/${tripId}/album/${id}/comments`)
    setComments(res.data)
  }

  return (
    <div>
      <div className="ts-card bg-white p-3 mb-4">
        <h6>Upload a memory</h6>
        <div className="row g-2 align-items-end">
          <div className="col-md-3">
            <label className="form-label small">Day # (optional)</label>
            <input type="number" min="1" className="form-control" value={dayNumber}
              onChange={(e) => setDayNumber(e.target.value)} />
          </div>
          <div className="col-md-5">
            <label className="form-label small">Caption (optional)</label>
            <input className="form-control" value={caption} onChange={(e) => setCaption(e.target.value)} />
          </div>
          <div className="col-md-4">
            <input ref={fileInputRef} type="file" accept="image/*,video/*" className="form-control"
              onChange={handleUpload} disabled={uploading} />
          </div>
        </div>
      </div>

      <div className="row g-3">
        {media.map((m) => (
          <div className="col-md-4" key={m.id}>
            <div className="ts-card bg-white overflow-hidden">
              {m.mediaType === 'VIDEO' ? (
                <video src={`${fileBaseUrl}${m.filePath}`} controls className="w-100" style={{ maxHeight: 220, objectFit: 'cover' }} />
              ) : (
                <img src={`${fileBaseUrl}${m.filePath}`} alt={m.caption || ''} className="w-100" style={{ maxHeight: 220, objectFit: 'cover' }} />
              )}
              <div className="p-2">
                {m.caption && <p className="small mb-1">{m.caption}</p>}
                <p className="small text-muted mb-2">
                  {m.uploadedByName}{m.dayNumber ? ` · Day ${m.dayNumber}` : ''}
                </p>
                <div className="d-flex gap-2">
                  <button className={`btn btn-sm ${m.likedByMe ? 'btn-primary' : 'btn-outline-primary'}`} onClick={() => toggleLike(m.id)}>
                    ❤ {m.likeCount}
                  </button>
                  <button className="btn btn-sm btn-outline-secondary" onClick={() => toggleComments(m.id)}>💬</button>
                  <button className="btn btn-sm btn-outline-danger" onClick={() => remove(m.id)}>Delete</button>
                </div>
                {openComments === m.id && (
                  <div className="mt-2 border-top pt-2">
                    {comments.map((c) => (
                      <p key={c.id} className="small mb-1"><strong>{c.userName}:</strong> {c.comment}</p>
                    ))}
                    <div className="d-flex gap-2 mt-1">
                      <input className="form-control form-control-sm" placeholder="Comment…"
                        value={commentText} onChange={(e) => setCommentText(e.target.value)} />
                      <button className="btn btn-sm btn-primary" onClick={() => addComment(m.id)}>Post</button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
        {media.length === 0 && <p className="text-muted">No memories uploaded yet.</p>}
      </div>
    </div>
  )
}
